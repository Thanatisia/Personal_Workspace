/* Config edits for JSON, XML etc. */
package com.example.extdbms;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.app.Application;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

/* External Libraries */
import com.example.Externals.utilities;

public class json_configs extends AppCompatActivity {
    /* Application Variables */
    Application app = new Application();
    Activity a = this;
    Context c = this;

    /* Widgets */
    Button btn_overwrite_current_config;
    Button btn_reset_to_default_json;
    EditText et_jsonConfig;

    //Global variables
    String extra_data_json_text = "";
    String extra_data_2_config_path = "";

    //Local Variables
    String tmp = "";

    /* Libraries */
    utilities util;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_json_configs);
        init();

        Bundle extras = getIntent().getExtras();
        if(!(extras == null))
        {
            // get data via the key
            extra_data_json_text = extras.getString("JSON_TEXT");
            extra_data_2_config_path = extras.getString("JSON_PATH");
        }
        et_jsonConfig.setText(extra_data_json_text);

        //Set title
        //a.setTitle("JSON Configuration");
        setTitle("JSON Configuration");

        /* Save edited config to default */
        btn_overwrite_current_config.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                tmp = et_jsonConfig.getText().toString();
                int et_len = 0;
                et_len = tmp.length();
                Toast.makeText(getApplicationContext(),
                        "Config Path - Overwrite" + " " + "[" + extra_data_2_config_path + "]" + "\n" +
                        "Save:" + " " + "[" + "\n" + tmp + "\n" + "]" + "\n",
                        Toast.LENGTH_LONG).show();
            }
        });

        /* Reset edited config back to default */
        btn_reset_to_default_json.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                et_jsonConfig.setText(extra_data_json_text);
            }
        });
    }

    void init()
    {
        /* Libraries */
        util = new utilities();

        /* Widgets */
        btn_overwrite_current_config = (Button)findViewById(R.id.btn_save_json);
        btn_reset_to_default_json = (Button)findViewById(R.id.btn_reset_to_default);
        et_jsonConfig = (EditText)findViewById(R.id.et_json_config);
    }
}
