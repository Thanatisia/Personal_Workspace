package com.example.extdbms;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.SubMenu;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

/* Externals Library
    1. app_control : Application Control
    - prog_title
    - package_name
    - retrieve_program_details(Activity a)
        etc.

 */
import com.example.Externals.app_control;
import com.example.Externals.globals;
import com.example.Externals.utilities;
import com.example.Externals.list_utility;
import com.example.Externals.menu_utility;
import com.example.Security.security_management;
import com.example.Security.settings;
import com.example.JSON.JSONParser;

public class NoteBook extends AppCompatActivity {

    /* Application Environment Variables*/
    Context c = this;
    Activity a = this;
    //Application app = new Application();
    Class cl = MainActivity.class;

    /* Initialize list of roles */

    /* Library Imports */
    utilities util;
    globals gl;
    list_utility list_ctrl;
    app_control appCtrl;
    menu_utility menuCtrl;
    security_management securityCtrl;
    settings application_settings;
    JSONParser jsonparser;

    /* Widgets */
    Button btn_saveText;
    Button btn_resetDefault;
    EditText et_textbox;

    //Global variables
    String SP_KEY_TEXT = "TEXT";
    String SP_KEY_FILEPATH = "FILE_PATH";
    String SP_KEY_FILENAME = "FILE_NAME";
    String extra_data_text = "";
    String extra_data_2_text_path = "";
    String out_file_name = "";

    /* SharedPreferences */
    SharedPreferences pref;
    SharedPreferences.Editor editor;
    String sharedPreferences_key = "MyPreferences";

    String KEY_BUILD_TYPE = "build_type";
    String build_type;

    /* Menu */
    Menu homepage_menu;
    MenuInflater inflater;
    public int MENU_ACTIVITIES = 0;
    public int SUBMENU_FILEMGMT = 1;
    public int SUBMENU_DESIGNROOM = 2;
    public int GROUP_ACTIVITIES = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_note_book);

        //Initialize
        init_class();
        init_widgets();

        Bundle extras = getIntent().getExtras();
        if(!(extras == null))
        {
            // get data via the key
            extra_data_text = extras.getString(SP_KEY_TEXT);
            extra_data_2_text_path = extras.getString(SP_KEY_FILEPATH);
            out_file_name = extras.getString(SP_KEY_FILENAME);
        }
        et_textbox.setText(extra_data_text);

        //Set Properties
        a.setTitle("Notebook");

        btn_saveText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String target_file_dir = extra_data_2_text_path;

                util.alert(c, "Output List to File", 1);
                String text_from_file = "";
                if(out_file_name != null && !out_file_name.isEmpty() && !out_file_name.equals("null"))
                {
                    //Read file - get number lines
                    //text_from_file = util.read_from_file(c, gl.sdcard + "//", out_file_name);
                    text_from_file = util.read_from_file(c, target_file_dir, out_file_name);

                    //Check Length
                    int read_file_input_length = text_from_file.length();

                    //File out_file = new File(gl.sdcard + "//", out_file_name);
                    File out_file = new File(target_file_dir, out_file_name);
                    if (!out_file.exists()) {
                        try {
                            out_file.createNewFile();
                        } catch (IOException e) {
                            e.printStackTrace();
                            util.alert(c, "IO Exception Caught:" + e.getMessage().toString(), 1);
                        } catch (Exception e) {
                            util.alert(c, "General Exception Caught:" + e.getMessage().toString(), 1);
                        }
                    }

                    //Create File Writer
                    FileWriter fw;
                    try {
//                        fw = new FileWriter(out_file, true /* Append */);
                        fw = new FileWriter(out_file, false /* Overwrite */);
                        BufferedWriter writer = new BufferedWriter(fw);
                        int tmp_i = 0;
                        String tmp_j = "";
                        //Write
                        writer.write(et_textbox.getText().toString());
                        writer.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                        util.alert(c, "IO Exception Caught:" + e.getMessage().toString(), 1);
                    } catch (Exception e) {
                        util.alert(c, "General Exception Caught:" + e.getMessage().toString(), 1);
                    }
                }
                else
                {
                    util.alert(c, "Database not opened.",1);

                    String OK_BUTTON_TEXT = "OK";
                    String label_title = "Please enter a filename to open";
                    boolean cancelable = false;
                    final EditText et = new EditText(c);
                    AlertDialog.Builder alertDialogBuilder = util.alert_dialog_build(c, label_title, et);   //Create Alert Dialog
                    util.alert_dialog_set_cancelable(alertDialogBuilder, cancelable);                    //Set non-cancelable

                    alertDialogBuilder.setPositiveButton(OK_BUTTON_TEXT, new DialogInterface.OnClickListener()    //Set Button and OK button
                    {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            String textfile_name_input = et.getText().toString();
                            util.alert(c, String.format("Opening new text file : [%1s]", textfile_name_input), 1);
                            out_file_name = textfile_name_input;

                            /* Overwrite opened text file with EditText values */
                        }
                    });
                    //create alert dialog and show
                    util.create_and_start_alertdialog(alertDialogBuilder);
                }
            }
        });

        btn_resetDefault.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                et_textbox.setText(extra_data_text);
            }
        });
    }
    void init_class()
    {
        util = new utilities();
        gl = new globals();
        list_ctrl = new list_utility();
        appCtrl = new app_control();
        menuCtrl = new menu_utility();
        securityCtrl = new security_management();
        application_settings = new settings();
        jsonparser = new JSONParser();
    }

    void init_widgets()
    {
        btn_saveText = (Button)findViewById(R.id.btn_save_text);
        btn_resetDefault = (Button)findViewById(R.id.btn_reset_to_default);
        et_textbox = (EditText)findViewById(R.id.et_text_box);
    }

    public boolean validate_debug(String uInput, String KEYWORD_PASS)
    {
        boolean token = false;
        if(uInput != null && !uInput.isEmpty() && !uInput.equals("null") && uInput.equals(KEYWORD_PASS))
        {
            token = true;
        }
        else
        {
            token = false;
        }
        return token;
    }

    /* Menu Functions
     * public boolean onCreateOptionsMenu(Menu menu) : To inflate and display the menu
     * public boolean onOptionsItemSelected(@NonNull MenuItem item) : Functions to execute when item is selected from Menu
     * */
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        /* Initialize Menu */
        // Enable Menu Icon Display
        menuCtrl.enable_menu_icon(menu); //Enable display of menu icon

        menu.addSubMenu(Menu.NONE, MENU_ACTIVITIES, Menu.NONE, "Activities");
        /* Create Menu with SubMenu */
        SubMenu submenu_activities = menu.findItem(MENU_ACTIVITIES).getSubMenu();
        submenu_activities.setIcon(R.mipmap.launcher_main_sqlite_logo);

        /* Clear all headers */
        submenu_activities.clear();
        /* Add SubMenu items to Menu with SubMenu */
        submenu_activities.add(GROUP_ACTIVITIES, SUBMENU_FILEMGMT, 0, "FileManagement");
        submenu_activities.add(GROUP_ACTIVITIES, SUBMENU_DESIGNROOM, 0, "Design Room");

        // Inflating Menu - preparing for display
        inflater = getMenuInflater();
        inflater.inflate(R.menu.main, menu); /* Inflate Menu */
        //return super.onCreateOptionsMenu(menu);
        return true;
    }
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        /* Handle Item Selection */
        //Using switch
//        switch(item.getItemId())
//        {
//            case R.id.menu_env_details:
//                tests();
//                return true;
//            default:
//                return super.onOptionsItemSelected(item);
//        }
        //Using IF else
        int id = item.getItemId();
        if(id == SUBMENU_FILEMGMT)
        {
            Intent filemgmt = new Intent(c, FileManagement.class);
            startActivity(filemgmt);
            finish();
            return true;
        }
        else if(id == SUBMENU_DESIGNROOM)
        {
            Intent designRoom = new Intent(c, DesignRoom.class);
            startActivity(designRoom);
            finish();
            return true;
        }
        else
        {
            return super.onOptionsItemSelected(item);
        }
        //return super.onOptionsItemSelected(item);
    }

    /* Back-button is pressed */
    @Override
    public void onBackPressed() {
        new AlertDialog.Builder(this)
                //.setTitle("Really Exit?")
                .setTitle("Want to end editor?")
                .setMessage("Are you sure you want to end The Editor?")
                .setNegativeButton(android.R.string.no, null)
                .setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface arg0, int arg1) {
                        NoteBook.super.onBackPressed();
                    }
                }).create().show();
        //super.onBackPressed();
    }
}
