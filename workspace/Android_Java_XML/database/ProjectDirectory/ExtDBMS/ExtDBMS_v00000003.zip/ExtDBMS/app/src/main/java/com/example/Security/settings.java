/*
Global settings for the program
- i.e.
    1. program_name
    2. program_version
    3. light brightness
    4. default parameters
 */
package com.example.Security;

public class settings {
    public String default_title = "ExtDBMS";
}
