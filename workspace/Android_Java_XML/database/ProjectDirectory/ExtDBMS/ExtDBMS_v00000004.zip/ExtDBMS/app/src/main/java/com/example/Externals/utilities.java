package com.example.Externals;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.arch.core.util.Function;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Array;
import java.lang.reflect.Method;

public class utilities {
    /*
    External classes and functions
    - must put [public]
     */
    public void alert(Context c, String message, Integer LENGTH_ID)
    {
        switch(LENGTH_ID)
        {
            case 0:
                Toast.makeText(c, message, Toast.LENGTH_SHORT).show();
                break;
            case 1:
                Toast.makeText(c, message, Toast.LENGTH_LONG).show();
                break;
            default:
                Toast.makeText(c,"Invalid Toast ID", Toast.LENGTH_LONG).show();
                break;
        }
    }

    public AlertDialog.Builder alert_dialog_build(Context c, String label_title, View view)
    {
        /* Create a popup for MENU_DEBUG : Validate role */
        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(c);

        // set prompts.xml to alertdialog builder
        alertDialogBuilder.setView(view);
        alertDialogBuilder.setTitle(label_title);

        return alertDialogBuilder;
    }

    public void alert_dialog_set_cancelable(AlertDialog.Builder builder_object, boolean cancelable)
    {
        builder_object.setCancelable(cancelable);
    }

    public AlertDialog create_alertdialog(AlertDialog.Builder alertDialogBuilder)
    {
        AlertDialog alertdialog = alertDialogBuilder.create();
        return alertdialog;
    }
    public void start_alertdialog(AlertDialog alertDialog)
    {
        alertDialog.show();
    }

    public AlertDialog create_and_start_alertdialog(AlertDialog.Builder alertDialogBuilder)
    {
        AlertDialog alertDialog = alertDialogBuilder.create();
        alertDialog.show();
        return alertDialog;
    }

    public void create_folder(Context c, String path)
    {
        File folder = new File(path);
        boolean success = true;
        if (!folder.exists()) {
            success = folder.mkdirs();
        }
        if (success) {
            // Do something on success
            Toast.makeText(c, "Successfully created folder : " + "[" + path + "]", Toast.LENGTH_LONG);
        } else {
            // Do something else on failure
            Toast.makeText(c, "Error creating folder : " + "[" + path + "]", Toast.LENGTH_LONG);
        }
    }

    public void write_output(Context c, String path, String file_name, String text_to_write)
    {
        File out_file = new File(path, file_name);
        if (!out_file.exists()) {
            try {
                out_file.createNewFile();
            } catch (IOException e) {
                e.printStackTrace();
                Toast.makeText(c, "IO Exception Caught:" + e.getMessage().toString(), Toast.LENGTH_LONG).show();
            } catch (Exception e) {
                Toast.makeText(c, "General Exception Caught:" + e.getMessage().toString(), Toast.LENGTH_LONG).show();
            }
        }

        //Create File Writer
        FileWriter fw;
        try {
//            fw = new FileWriter(out_file, true /* Append */);
            fw = new FileWriter(out_file, false /* Overwrite */);
            BufferedWriter writer = new BufferedWriter(fw);
            //Write
            writer.write(text_to_write);
            writer.close();
        } catch (IOException e) {
            e.printStackTrace();
            Toast.makeText(c, "IO Exception Caught:" + e.getMessage().toString(), Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            Toast.makeText(c, "General Exception Caught:" + e.getMessage().toString(), Toast.LENGTH_LONG).show();
        }
    }

    public String read_file_from_asset(Context c, String read_file_name)
    {
        String text_from_file = "";
        InputStream is;
        int length = 0;
        byte[] data;
        try {
            is = c.getAssets().open(read_file_name);
            length = is.available();
            data = new byte[length];
            is.read(data);
            text_from_file = new String(data);
        } catch (IOException e) {
            e.printStackTrace();
            Toast.makeText(c, "IO Exception Caught:" + e.getMessage().toString(), Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            Toast.makeText(c, "General Exception Caught:" + e.getMessage().toString(), Toast.LENGTH_LONG).show();
        }
        return text_from_file;
    }

    public String read_from_file(Context c, String file_directory, String read_file_name)
    {
        String text_from_file = "";
        File read_file = new File(file_directory, read_file_name);
        if (!read_file.exists()) {
            try {
                read_file.createNewFile();
            } catch (IOException e) {
                e.printStackTrace();
                Toast.makeText(c, "IO Exception Caught:" + e.getMessage().toString(), Toast.LENGTH_LONG).show();
            } catch (Exception e) {
                Toast.makeText(c, "General Exception Caught:" + e.getMessage().toString(), Toast.LENGTH_LONG).show();
            }
        }
        else {
            StringBuilder sb = new StringBuilder();
            FileReader fr;
            //Read data from file
            BufferedReader reader = null;
            try {
                fr = new FileReader(read_file);
                reader = new BufferedReader(fr);
                String line;
                while ((line = reader.readLine()) != null) {
                    text_from_file += line.toString();
                    text_from_file += "\n";
                }
                reader.close();
            } catch (IOException e) {
                e.printStackTrace();
                Toast.makeText(c, "IO Exception Caught:" + e.getMessage().toString(), Toast.LENGTH_LONG).show();
            } catch (Exception e) {
                Toast.makeText(c, "General Exception Caught:" + e.getMessage().toString(), Toast.LENGTH_LONG).show();
            }
        }
        return text_from_file;
    }
}
