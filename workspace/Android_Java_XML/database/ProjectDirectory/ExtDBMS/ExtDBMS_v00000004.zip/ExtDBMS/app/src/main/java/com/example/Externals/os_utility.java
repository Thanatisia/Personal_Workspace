package com.example.Externals;

import android.os.Build;

import java.util.ArrayList;
import java.util.List;

public class os_utility {

    public int SDK_BUILD_VERSION_ICE_CREAM_SANDWHICH = Build.VERSION_CODES.ICE_CREAM_SANDWICH;
    public List<Object> version_codes = new ArrayList<Object>(){
        {
            add("Invalid Code");                              //0th index - Invalid version code ; TRUTH: I put this here to make Build.VERSION_CODES at their exact build SDK version, and not -1 (without this, the index is [sdk build version - 1]
            add(Build.VERSION_CODES.BASE);                    //1
            add(Build.VERSION_CODES.BASE_1_1);                //2
            add(Build.VERSION_CODES.CUPCAKE);                 //3
            add(Build.VERSION_CODES.DONUT);                   //4
            add(Build.VERSION_CODES.ECLAIR);                  //5
            add(Build.VERSION_CODES.ECLAIR_0_1);              //6
            add(Build.VERSION_CODES.ECLAIR_MR1);              //7
            add(Build.VERSION_CODES.FROYO);                   //8
            add(Build.VERSION_CODES.GINGERBREAD);             //9
            add(Build.VERSION_CODES.GINGERBREAD_MR1);         //10
            add(Build.VERSION_CODES.HONEYCOMB);               //11
            add(Build.VERSION_CODES.HONEYCOMB_MR1);           //12
            add(Build.VERSION_CODES.HONEYCOMB_MR2);           //13
            add(Build.VERSION_CODES.ICE_CREAM_SANDWICH);      //14
            add(Build.VERSION_CODES.ICE_CREAM_SANDWICH_MR1);  //15
            add(Build.VERSION_CODES.JELLY_BEAN);              //16
            add(Build.VERSION_CODES.JELLY_BEAN_MR1);          //17
            add(Build.VERSION_CODES.JELLY_BEAN_MR2);          //18
            add(Build.VERSION_CODES.KITKAT);                  //19
            add(Build.VERSION_CODES.KITKAT_WATCH);            //20
            add(Build.VERSION_CODES.LOLLIPOP);                //21
            add(Build.VERSION_CODES.LOLLIPOP_MR1);            //22
            add(Build.VERSION_CODES.M);                       //23
            add(Build.VERSION_CODES.N);                       //24
            add(Build.VERSION_CODES.N_MR1);                   //25
            add(Build.VERSION_CODES.O);                       //26
            add(Build.VERSION_CODES.O_MR1);                   //27
            add(Build.VERSION_CODES.P);                       //28
            add(Build.VERSION_CODES.Q);                       //29
        }
    };

    public String get_device_model()
    {
        String model = Build.MODEL;
        return model;
    }

    public int get_build_version()
    {
        int build_version = 0;
        build_version = Build.VERSION.SDK_INT;
        return build_version;
    }

    public int check_valid_build_version_code(int target_sdk_build_version_code)
    {
        int valid_token = 0;
        int version_codes_size = version_codes.size();
        if(target_sdk_build_version_code > (version_codes_size - 1)) /* - 1 because index starts from 0, and 0 is String "invalid code" - and there are currently 29 build versions */
        {
            valid_token = -1;
        }
        else
        {
            if(target_sdk_build_version_code == 0)
            {
                valid_token = -1;
            }
            else
            {
                //valid_token = Integer.parseInt(version_codes_size.get(target_sdk_build_version_code).toString());
                valid_token = 1;
            }
        }
        return valid_token;
    }

    public String get_build_version_code_name(int target_sdk_build_version_code)
    {
        String version_code_name = "";
        switch(target_sdk_build_version_code)
        {
            case 1:
                version_code_name = "Base_v1";
                break;
            case 2:
                version_code_name = "Base_update_1";
                break;
            case 3:
                version_code_name = "Cupcake";
                break;
            case 4:
                version_code_name = "Donut";
                break;
            case 5:
                version_code_name = "Eclair";
                break;
            case 6:
                version_code_name = "Eclaire_update_1";
                break;
            case 7:
                version_code_name = "Eclaire MR1";
                break;
            case 8:
                version_code_name = "Froyo";
                break;
            case 9:
                version_code_name = "Gingerbread";
                break;
            case 10:
                version_code_name = "Gingerbread MR1";
                break;
            case 11:
                version_code_name = "Honeycomb";
                break;
            case 12:
                version_code_name = "Honeycomb MR1";
                break;
            case 13:
                version_code_name = "Honeycomb MR2";
                break;
            case 14:
                version_code_name = "Ice Cream Sandwich";
                break;
            case 15:
                version_code_name = "Ice Cream Sandwhich MR1";
                break;
            case 16:
                version_code_name = "Jellybean";
                break;
            case 17:
                version_code_name = "Jellybean MR1";
                break;
            case 18:
                version_code_name = "Jellybean MR2";
                break;
            case 19:
                version_code_name = "Kitkat";
                break;
            case 20:
                version_code_name = "Kitkatch Watch";
                break;
            case 21:
                version_code_name = "Lollipop";
                break;
            case 22:
                version_code_name = "Lollipop MR1";
                break;
            case 23:
                version_code_name = "Marshmallow";
                break;
            case 24:
                version_code_name = "Nougat";
                break;
            case 25:
                version_code_name = "Nougat MR1";
                break;
            case 26:
                version_code_name = "Oreo";
                break;
            case 27:
                version_code_name = "Oreo MR1";
                break;
            case 28:
                version_code_name = "Pie";
                break;
            case 29:
                version_code_name = "Android 10";
                break;
            default: /* 0 OR any invalid version */
                version_code_name = "Invalid";
                break;
        }
        return version_code_name;
    }
    public String get_build_code_android_version(int target_sdk_build_version_code)
    {
        /*
        i.e.
            SDK 1 : Base - Original v1
            SDK 2 : First official android update - v1.1
            SDK 3 : v1.5
         */
        String android_version = "";
        switch(target_sdk_build_version_code)
        {
            case 1:
                android_version = "1";
                break;
            case 2:
                android_version = "1.1";
                break;
            case 3:
                android_version = "1.5";
                break;
            case 4:
                android_version = "1.6";
                break;
            case 5:
                android_version = "2.0;";
                break;
            case 6:
                android_version = "2.0.1";
                break;
            case 7:
                android_version = "2.1";
                break;
            case 8:
                android_version = "2.2";
                break;
            case 9:
                android_version = "2.3";
                break;
            case 10:
                android_version = "2.33";
                break;
            case 11:
                android_version = "3.0";
                break;
            case 12:
                android_version = "3.1";
                break;
            case 13:
                android_version = "3.2";
                break;
            case 14:
                android_version = "4.0";
                break;
            case 15:
                android_version = "4.03";
                break;
            case 16:
                android_version = "4.1";
                break;
            case 17:
                android_version = "4.2";
                break;
            case 18:
                android_version = "4.3";
                break;
            case 19:
                android_version = "4.4";
                break;
            case 20:
                android_version = "4.4W";
                break;
            case 21:
                android_version = "5.0";
                break;
            case 22:
                android_version = "5.1";
                break;
            case 23:
                android_version = "6.0";
                break;
            case 24:
                android_version = "7.0";
                break;
            case 25:
                android_version = "7.1";
                break;
            case 26:
                android_version = "8.0";
                break;
            case 27:
                android_version = "8.1";
                break;
            case 28:
                android_version = "9.0";
                break;
            case 29:
                android_version = "10.0";
                break;
            default: /* 0 OR any invalid version */
                android_version = "0.0";
                break;
        }
        return android_version;
    }

    public int check_build_version(int target_build_sdk_version)
    {
        /*
             if token == target_build_sdk_version : Your SDK Build version is EQUALS TO your target build sdk version
        else if token <  target_build_sdk_version : Your SDK Build version is LESS THAN your target build sdk version
        else if token <= target_build_sdk_version : Your SDK Build version is LESS THAN OR EQUALS TO your target build sdk version
        else if token >  target_build_sdk_version : Your SDK Build version is MORE THAN your target build sdk version
        else if token >= target_build_sdk_version : Your SDK Build version is MORE THAN OR EQUALS TO your target build sdk version

        else: token = -1
         */
        target_build_sdk_version -= 1;

        int token = 0;
        if(get_build_version() == target_build_sdk_version)
        {
            token = 0;
        }
        else if(get_build_version() < target_build_sdk_version)
        {
            token = 1;
        }
        else if(get_build_version() <= target_build_sdk_version)
        {
            token = 2;
        }
        else if(get_build_version() > target_build_sdk_version)
        {
            token = 3;
        }
        else if(get_build_version() >= target_build_sdk_version)
        {
            token = 4;
        }
        else
        {
            token = -1;
        }
        return token;
    }
}