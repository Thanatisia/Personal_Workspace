/*
* Utility Class for Menus
* */
package com.example.Externals;

import android.view.Menu;
import android.view.MenuItem;
import android.view.SubMenu;

import androidx.appcompat.view.menu.MenuBuilder;

public class menu_utility {
    /* Menu Controls */
    public MenuItem add_menu(Menu menu_variable, int item_group_id, int item_unique_id, int menu_item_position, String title )
    {
        /*
        item_group_id = group_id
        item_unique_id = item_id
        menu_item_position = order
         */
        MenuItem out_menu = menu_variable.add(item_group_id, item_unique_id, menu_item_position, title);
        return out_menu;
    }

    public SubMenu add_submenu(Menu menu_variable, String submenu_text)
    {
        SubMenu ret_submenu;
        ret_submenu = menu_variable.addSubMenu(submenu_text);
        return ret_submenu;
    }

    /* Enabling Menu Features */
    public void enable_menu_icon(Menu menu)
    {
        if(menu instanceof MenuBuilder)
        {
            MenuBuilder m = (MenuBuilder) menu;
            m.setOptionalIconsVisible(true);
        }
    }

    /* Designing Menu Details */
    public void set_icon(MenuItem menu_item, int icon_id)
    {
        menu_item.setIcon(icon_id);
    }
    public void set_shortcut(MenuItem menu_item, char ...shortcut_elements)
    {
        int shortcut_elements_length = shortcut_elements.length;
        if(shortcut_elements_length == 1)
        {
            if(Character.isDigit(shortcut_elements[0])) {
                menu_item.setNumericShortcut(shortcut_elements[0]);
            }
            else if(Character.isLetter(shortcut_elements[0]))
            {
                menu_item.setAlphabeticShortcut(shortcut_elements[0]);
            }
        }
        else if(shortcut_elements_length == 2)
        {
            menu_item.setShortcut(shortcut_elements[0], shortcut_elements[1]);
        }
    }
}
