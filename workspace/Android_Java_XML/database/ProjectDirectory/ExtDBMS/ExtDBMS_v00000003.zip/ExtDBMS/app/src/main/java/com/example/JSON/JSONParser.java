package com.example.JSON;

import android.app.Activity;
import android.app.Application;
import android.content.Context;
import android.os.AsyncTask;
import android.util.Log;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class JSONParser {
    JSONObject reader;
    List<String> json_keys = new ArrayList<>();
    List<String> json_values = new ArrayList<>();
    Application app;

    void init_class()
    {
        app = new Application();
    }

    void init_objects(Context c, String json_file_name)
    {
        try {
            reader = new JSONObject(json_file_name);
        } catch (JSONException e) {
            e.printStackTrace();
            Toast.makeText(c, "JSON Exception Caught:" + " " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
        json_keys = new ArrayList<>();
    }

    public String loadJSONFromAsset(Context c, String json_file_name) {
        init_class();
        String json = null;
        try {
            InputStream is = c.getAssets().open(json_file_name);
            int size = is.available();
            byte[] buffer = new byte[size];
            is.read(buffer);
            is.close();
            json = new String(buffer, "UTF-8");
        } catch (IOException ex) {
            ex.printStackTrace();
            Toast.makeText(c, "IO Exception Caught:" + " " + ex.getMessage(), Toast.LENGTH_LONG).show();
            return null;
        }
        return json;
    }

    public JSONObject get_json_object(Context c, String json_file_name)
    {
        JSONObject json_obj = null;
        try {
            json_obj = new JSONObject(json_file_name);
        } catch (JSONException e) {
            e.printStackTrace();
            Toast.makeText(c, "JSON Exception Caught:" + " " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
        return json_obj;
    }

    public List<String> get_json_keys(Context c, String json_file_name) {
        init_class();

        if(reader == null)
        {
            init_objects(c, json_file_name);
        }

        try {
            for (int i = 0; i < reader.names().length(); i++) {
                try {
                    json_keys.add(reader.names().get(i).toString());
                } catch (JSONException e) {
                    e.printStackTrace();
                    Toast.makeText(c, "JSON Exception Caught:" + " " + e.getMessage(), Toast.LENGTH_LONG).show();
                }
            }
        } catch (NullPointerException e) {
            e.printStackTrace();
            Toast.makeText(c, "Null Pointer Exception Caught:" + " " + e.getMessage(), Toast.LENGTH_LONG).show();
        }

        return json_keys;
    }

    public List<String> get_json_values(Context c, String json_file_name)
            /* List<String> json_key_set */
    {
        init_class();

        //Clear existing keys before use
        json_keys.clear();
        json_values.clear();

//        int json_keyset_size = json_key_set.size();
//        JSONArray key_arr = new JSONArray();
//
//        for(int i=0; i < json_keyset_size; i++)
//        {
//            //json_values.add(json_key_set.get(i));
//            //json_values.add(json_key_set.get(i));
//            key_arr =
//        }

        if(reader == null)
        {
            init_objects(c, json_file_name);
        }

        if(json_keys.size() <= 0) {
            try {
                for (int i = 0; i < reader.names().length(); i++) {
                    try {
                        json_keys.add(reader.names().get(i).toString());
                    } catch (JSONException e) {
                        e.printStackTrace();
                        Toast.makeText(c, "JSON Exception Caught:" + " " + e.getMessage(), Toast.LENGTH_LONG).show();
                    }
                }
            } catch (NullPointerException e) {
                e.printStackTrace();
                Toast.makeText(c, "Null Pointer Exception Caught:" + " " + e.getMessage(), Toast.LENGTH_LONG).show();
            }
        }

        JSONObject sub_object;
        JSONArray curr_val;

        List<String> internal_keys = new ArrayList<>();
        Iterator<String> it;

        for(int i=0; i < json_keys.size(); i++) {
            try {
                sub_object = reader.getJSONObject(json_keys.get(i));
                it = sub_object.keys();
                while(it.hasNext()) //While still have
                {
                    String key = it.next();
                    json_values.add(sub_object.optString(key));
                    Log.i("TAG","key:"+key +"--Value::"+sub_object.optString(key));
                }
            }
            catch (JSONException e) {
                e.printStackTrace();
                Toast.makeText(c, "JSON Exception Caught:" + " " + e.getMessage(), Toast.LENGTH_LONG).show();
            }
        }
        return json_values;
    }
    public List<String> get_json_values_from_category_key(Context c, String json_file_name, String key_name)
        /* List<String> json_key_set */
    {
        init_class();

        //Clear existing keys before use
        json_keys.clear();
        json_values.clear();

        if(reader == null)
        {
            init_objects(c, json_file_name);
        }

        if(json_keys.size() <= 0) {
            try {
                for (int i = 0; i < reader.names().length(); i++) {
                    try {
                        json_keys.add(reader.names().get(i).toString());
                    } catch (JSONException e) {
                        e.printStackTrace();
                        Toast.makeText(c, "JSON Exception Caught:" + " " + e.getMessage(), Toast.LENGTH_LONG).show();
                    }
                }
            } catch (NullPointerException e) {
                e.printStackTrace();
                Toast.makeText(c, "Null Pointer Exception Caught:" + " " + e.getMessage(), Toast.LENGTH_LONG).show();
            }
        }

        JSONObject sub_object;
        JSONArray curr_val;

        List<String> internal_keys = new ArrayList<>();
        Iterator<String> it;

        try {
            sub_object = reader.getJSONObject(key_name);
            it = sub_object.keys();
            while(it.hasNext()) //While still have
            {
                String key = it.next();
                json_values.add(sub_object.optString(key));
                Log.i("TAG","key:"+key +"--Value::"+sub_object.optString(key));
            }
        }
        catch (JSONException e) {
            e.printStackTrace();
            Toast.makeText(c, "JSON Exception Caught:" + " " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
        return json_values;
    }
    public List<Object> get_json_key_value_from_category(Context c, String json_file_name, String header_name)
        /* List<String> json_key_set */
    {
        init_class();

        //Clear existing keys before use
        json_keys.clear();
        json_values.clear();

        if(reader == null)
        {
            init_objects(c, json_file_name);
        }

        /* Obtain all keys */
        if(json_keys.size() <= 0) {
            try {
                for (int i = 0; i < reader.names().length(); i++) {
                    try {
                        json_keys.add(reader.names().get(i).toString());
                    } catch (JSONException e) {
                        e.printStackTrace();
                        Toast.makeText(c, "JSON Exception Caught:" + " " + e.getMessage(), Toast.LENGTH_LONG).show();
                    }
                }
            } catch (NullPointerException e) {
                e.printStackTrace();
                Toast.makeText(c, "Null Pointer Exception Caught:" + " " + e.getMessage(), Toast.LENGTH_LONG).show();
            }
        }

        JSONObject sub_object;
        JSONArray curr_val;

        List<String> internal_keys = new ArrayList<>();
        Iterator<String> it;

        List<String> json_key_tmp = new ArrayList<>();
        List<Object> json_key_value = new ArrayList<>();
        List<String> json_value_tmp = new ArrayList<>();
        List<Object> json_consolidated = new ArrayList<>();

        try {
            sub_object = reader.getJSONObject(header_name); //Get all values under this category
            it = sub_object.keys();
            while(it.hasNext()) //While still have
            {
                String key = it.next();
                json_key_tmp.add(key); //Add key
                json_values.add(sub_object.optString(key));
                Log.i("TAG","key:"+key +"--Value::"+sub_object.optString(key));
            }

            /* Getting the consolidation of data
            Intended Format: [ <header>, [key, [values from key] ], [key, [values from key] ] ]
            Output Format: <header>, [values from key]

            json_consolidated.add(key_name);
            for (int j = 0; j < json_values.size(); j++) {
                json_value_tmp.add(json_values.get(j));
            }
            json_consolidated.add(json_value_tmp);
             */
            json_consolidated.add(header_name); //header
            for (int j = 0; j < json_values.size(); j++)
            {
                //json_consolidated.add(json_key_tmp.get(j));
                json_key_value.add(json_key_tmp.get(j));
                //json_consolidated.add(json_values.get(j));
                json_key_value.add(json_values.get(j));
            }
            json_consolidated.add(json_key_value);
        }
        catch (JSONException e) {
            e.printStackTrace();
            Toast.makeText(c, "JSON Exception Caught:" + " " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
        return json_consolidated;
    }

    public String get_json_key_value(Context c, String json_file_name, String header_name, String key_name)
    {
        List<Object> values = get_json_key_value_from_category(c, json_file_name ,header_name); //Get key-value combination from JSON's header name
        Object ret = values.get(1); //Get the key-value, .get(0) = the header_name - i.e. "project", "sys", hence .get(1)
        List<Object> element_set = (List<Object>)ret; //Convert the result of the 1st index to ArrayList/List of variable type for Use
        Object value = element_set.get(element_set.indexOf(key_name) + 1); //Get the value of the key (which is usually (index of [key] + 1) - i.e. "name" : "ExtDBMS" , with "name" being index of key, "ExtDBMS" being "name" + 1
        String retStr = value.toString();
        return retStr;
    }
}
