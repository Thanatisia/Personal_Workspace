package com.example.Security;

import android.app.Application;

import java.util.ArrayList;
import java.util.List;

public class security_management extends Application {

    private List<String> build_roles = new ArrayList<String>()
    {
        {
            add("DEBUG");
            add("RELEASE");
        }
    };
    //private String build_type;
    private String build_type = build_roles.get(build_roles.indexOf("RELEASE"));

    public void set_role(String role)
    {
        if(build_roles.contains(role))
        {
            this.build_type = build_roles.get(build_roles.indexOf(role));
        }
    }

    public String get_build_type()
    {
        return build_type;
    }

    public int check_build_type()
    {
        /*
        If build_type == "DEBUG"
        {
            //Return 1, Allow DEBUG-mode only features
        }
        else if build_type == "RELEASE"
        {
            //Return 0, Allow non-debug-mode only features
        }
        else
        {
            //Invalid type - default to RELEASE
        }
         */
        if(build_type.equals("DEBUG"))
        {
            return 1;
        }
        else
        {
            return 0;
        }
    }
}
