package com.example.extdbms;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class CountryManager extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_country_manager);
    }
}
