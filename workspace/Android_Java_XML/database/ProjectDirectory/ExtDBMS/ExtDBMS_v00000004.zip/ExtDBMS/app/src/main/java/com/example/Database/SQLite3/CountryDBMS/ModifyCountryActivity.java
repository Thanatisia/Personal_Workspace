package com.example.Database.SQLite3.CountryDBMS;

import android.app.Activity;
import android.app.Application;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.annotation.Nullable;

import com.example.Database.SQLite3.CountryDBMS.Helpers.CountryDBManager;
import com.example.extdbms.CountryListActivity;
import com.example.extdbms.R;

public class ModifyCountryActivity extends Activity implements View.OnClickListener {
    Context c = this;
    Activity a = this;
    Application app = new Application();

    private Button updateBtn, deleteBtn;
    private EditText subjectText;
    private EditText descText;
    private long row_id;

    private CountryDBManager dbManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_country_modify_record);
        setTitle("Modify Record");

        init_views();

        /* Database crashes on opening */
        dbManager = new CountryDBManager(c);
        dbManager.open();

        Intent intent = getIntent();
        String id = intent.getStringExtra("id");
        String name = intent.getStringExtra("title");
        String desc = intent.getStringExtra("desc");

        row_id = Long.parseLong(id);

        subjectText.setText(name);
        descText.setText(desc);

        updateBtn.setOnClickListener(this);
        deleteBtn.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch(v.getId())
        {
            case R.id.btn_update:
                String subject = subjectText.getText().toString();
                String desc = descText.getText().toString();
                dbManager.update(row_id, subject, desc);
                this.returnHome();
                break;
            case R.id.btn_delete:
                dbManager.delete(row_id);
                this.returnHome();
                break;
        }
    }

    void init_views()
    {
        subjectText = (EditText)findViewById(R.id.subject_edittext);
        descText = (EditText)findViewById(R.id.description_edittext);
        deleteBtn = (Button)findViewById(R.id.btn_delete);
        updateBtn = (Button)findViewById(R.id.btn_update);
    }

    public void returnHome()
    {
        Intent home_intent = new Intent(c, CountryListActivity.class);
        home_intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        startActivity(home_intent);
    }
}