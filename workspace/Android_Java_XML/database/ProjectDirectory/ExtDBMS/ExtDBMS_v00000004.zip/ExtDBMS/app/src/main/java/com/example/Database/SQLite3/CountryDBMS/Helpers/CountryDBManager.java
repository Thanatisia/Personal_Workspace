/*
CountryDBManager
 - Able to perform all database CRUD (Create, Read, Update, Delete) Operations
 */
package com.example.Database.SQLite3.CountryDBMS.Helpers;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;

public class CountryDBManager {
    private CountryDatabaseHelper country_dbHelper; //DatabaseHelper class
    private Context context;
    private SQLiteDatabase db; //SQLite Database class
    public String database_path = "";

    /* Class Contructor - is executed when used
        DatabaseHelper is initialized and the CRUD Operations are defined
    */
    public CountryDBManager(Context c)
    {
        context = c;
    }

    /*
    Overload Class Constructor function - open()
        - if SQLException is met - automatically throw SQLException
     */
    public CountryDBManager open() throws SQLException
    {
        country_dbHelper = new CountryDatabaseHelper(context);
        db = country_dbHelper.getWritableDatabase(); /* Start Writable/Editable Database - prepare for edit */
        database_path = db.getPath();
        return this;
    }

    public void set_database_path(String db_path)
    {
        database_path = db_path;
    }

    public static void export_sqlite_database(String db_name)
    {
        /*
        Backup and Export database from default internal folder:
         */
    }

    public static void import_sqlite_database(String db_name)
    {
        /*
        Backup and Export database from default internal folder:
         */
    }

    /* Close the database connection */
    public void close()
    {
        country_dbHelper.close();
    }

    /* Insert the values into the TABLE_NAME of the database */
    public void insert(String name, String description)
    {
        ContentValues contentValue_container = new ContentValues(); //ContentValues is essentially a container to put values
        contentValue_container.put(country_dbHelper.SUBJECT, name);
        contentValue_container.put(country_dbHelper.DESCRIPTION, description);
        db.insert(CountryDatabaseHelper.TABLE_NAME, null, contentValue_container); /* Insert the values in contentValue into the database in [TABLE_NAME] */
    }

    /* Fetch/retrieve the data
    * A cursor represents the entire set of the query
    * - Once the query is fetched,
    * - a call to "cursor.moveToFirst"() is made
    * - Calling "cursor.moveToFirst()" does 2 things
    *   - Allows us to test where the query returned an empty set - by testing the return value
    *   - It moves the cursor to the first result (when the set is not empty
    *
    * - Put SELECTION, SELECTION_ARGS, GROUP_BY, HAVING and ORDER_BY as null means
    *   - Retrieve/fetch all records
    * */
    public Cursor fetch()
    {
        /* Put all columns of the table into an array */
        String[] columns = new String[]
                {
                   CountryDatabaseHelper.ROW_ID, CountryDatabaseHelper.SUBJECT, CountryDatabaseHelper.DESCRIPTION
                };
        Cursor cursor = db.query(CountryDatabaseHelper.TABLE_NAME, columns, null, null, null,null, null); //Set a cursor to point to query and point to the result  - Parameters: <Table_Name>, <All_columns - hence use columns array>, SELECT <selection>, selection arguments, GROUP BY filter, WHERE condition, ORDER BY condition

        if(cursor != null)
        {
            cursor.moveToFirst(); //If cursor is not empty, move back to the top - aka first column
        }

        return cursor;
    }

    /* Update Database Table Row columns */
    public int update(long row_id, String name, String description)
    {
        ContentValues contentValues = new ContentValues();
        contentValues.put(CountryDatabaseHelper.SUBJECT, name); //Put new value for column SUBJECT
        contentValues.put(CountryDatabaseHelper.DESCRIPTION, description);
        int i = db.update(CountryDatabaseHelper.TABLE_NAME, contentValues, CountryDatabaseHelper.ROW_ID + "=" + row_id, null); //Return value of the result; db.update(TABLE_NAME, <Container of new values>, <WHERE Condition - where your row_id equals to the target_id : Example: DatabaseHelper.Row_ID + "=" + row_id - SELECT name, country FROM COUNTRIES WHERE row_id = 5)
        return i;
    }

    /* Delete a specific row from TABLE_NAME WHERE target database row_id = user input
    - i.e. WHERE row_id = 5 : row 5
     */
    public void delete(long row_id)
    {
        db.delete(CountryDatabaseHelper.TABLE_NAME, CountryDatabaseHelper.ROW_ID + "=" + row_id, null);
    }
}
