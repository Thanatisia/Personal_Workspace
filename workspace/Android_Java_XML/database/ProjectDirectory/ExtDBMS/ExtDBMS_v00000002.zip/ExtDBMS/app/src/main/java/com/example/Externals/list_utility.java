package com.example.Externals;

import java.util.List;

public class list_utility {
    public String string_list_get_element(List<String> data_set, int id)
    {
        String element = "";
        element = data_set.get(id);
        return element;
    }

    public String list_get_element(List<Object> data_set, int id)
    {
        String element = "";
        element = data_set.get(id).toString();
        return element;
    }
}
