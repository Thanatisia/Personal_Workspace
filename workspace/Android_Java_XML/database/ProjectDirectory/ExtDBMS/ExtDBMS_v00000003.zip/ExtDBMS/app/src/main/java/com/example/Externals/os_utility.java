package com.example.Externals;

import android.os.Build;

import java.util.ArrayList;
import java.util.List;

public class os_utility {

    public int SDK_BUILD_VERSION_ICE_CREAM_SANDWHICH = Build.VERSION_CODES.ICE_CREAM_SANDWICH;
    public List<Object> version_codes = new ArrayList<Object>(){
        {
            add("Invalid Code");                              //0th index - Invalid version code ; TRUTH: I put this here to make Build.VERSION_CODES at their exact build SDK version, and not -1 (without this, the index is [sdk build version - 1]
            add(Build.VERSION_CODES.BASE);                    //1
            add(Build.VERSION_CODES.BASE_1_1);                //2
            add(Build.VERSION_CODES.CUPCAKE);                 //3
            add(Build.VERSION_CODES.DONUT);                   //4
            add(Build.VERSION_CODES.ECLAIR);                  //5
            add(Build.VERSION_CODES.ECLAIR_0_1);              //6
            add(Build.VERSION_CODES.ECLAIR_MR1);              //7
            add(Build.VERSION_CODES.FROYO);                   //8
            add(Build.VERSION_CODES.GINGERBREAD);             //9
            add(Build.VERSION_CODES.GINGERBREAD_MR1);         //10
            add(Build.VERSION_CODES.HONEYCOMB);               //11
            add(Build.VERSION_CODES.HONEYCOMB_MR1);           //12
            add(Build.VERSION_CODES.HONEYCOMB_MR2);           //13
            add(Build.VERSION_CODES.ICE_CREAM_SANDWICH);      //14
            add(Build.VERSION_CODES.ICE_CREAM_SANDWICH_MR1);  //15
            add(Build.VERSION_CODES.JELLY_BEAN);              //16
            add(Build.VERSION_CODES.JELLY_BEAN_MR1);          //17
            add(Build.VERSION_CODES.JELLY_BEAN_MR2);          //18
            add(Build.VERSION_CODES.KITKAT);                  //19
            add(Build.VERSION_CODES.KITKAT_WATCH);            //20
            add(Build.VERSION_CODES.LOLLIPOP);                //21
            add(Build.VERSION_CODES.LOLLIPOP_MR1);            //22
            add(Build.VERSION_CODES.M);                       //23
            add(Build.VERSION_CODES.N);                       //24
            add(Build.VERSION_CODES.N_MR1);                   //25
            add(Build.VERSION_CODES.O);                       //26
            add(Build.VERSION_CODES.O_MR1);                   //27
            add(Build.VERSION_CODES.P);                       //28
            add(Build.VERSION_CODES.Q);                       //29
        }
    };

    public int get_build_version()
    {
        int build_version = 0;
        build_version = Build.VERSION.SDK_INT;
        return build_version;
    }

    public int check_build_version(int target_build_sdk_version)
    {
        /*
             if token == target_build_sdk_version : Your SDK Build version is EQUALS TO your target build sdk version
        else if token <  target_build_sdk_version : Your SDK Build version is LESS THAN your target build sdk version
        else if token <= target_build_sdk_version : Your SDK Build version is LESS THAN OR EQUALS TO your target build sdk version
        else if token >  target_build_sdk_version : Your SDK Build version is MORE THAN your target build sdk version
        else if token >= target_build_sdk_version : Your SDK Build version is MORE THAN OR EQUALS TO your target build sdk version

        else: token = -1
         */
        target_build_sdk_version -= 1;

        int token = 0;
        if(get_build_version() == target_build_sdk_version)
        {
            token = 0;
        }
        else if(get_build_version() < target_build_sdk_version)
        {
            token = 1;
        }
        else if(get_build_version() <= target_build_sdk_version)
        {
            token = 2;
        }
        else if(get_build_version() > target_build_sdk_version)
        {
            token = 3;
        }
        else if(get_build_version() >= target_build_sdk_version)
        {
            token = 4;
        }
        else
        {
            token = -1;
        }
        return token;
    }
}