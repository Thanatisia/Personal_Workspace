/* Application Control */
package com.example.Externals;

import android.app.Activity;
import android.os.Environment;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class app_control {
    /* Initialize Activity */
    Activity activity = new Activity();

    /* Program details */
    public static String prog_title = "";
    public static String package_name = "";

    public List<String> retrieve_program_details(Activity a)
    {
        List<String> env_list = new ArrayList<>();
        prog_title = a.getTitle().toString();
        package_name = a.getPackageName();
        env_list.add(prog_title);
        env_list.add(package_name);
        return env_list;
    }

    public String get_application_title(Activity a)
    {
        String app_title = "";
        app_title = (String)a.getTitle();
        return app_title;
    }

    public String get_package_name(Activity a)
    {
        String package_name = "";
        package_name = a.getPackageName();
        return package_name;
    }
}
