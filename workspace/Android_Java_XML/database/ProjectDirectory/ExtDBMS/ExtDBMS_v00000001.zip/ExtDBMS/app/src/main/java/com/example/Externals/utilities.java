package com.example.Externals;

import android.content.Context;
import android.widget.Toast;

public class utilities {
    /*
    External classes and functions
    - must put [public]
     */
    public void alert(Context c, String message, Integer LENGTH_ID)
    {
        switch(LENGTH_ID)
        {
            case 0:
                Toast.makeText(c, message, Toast.LENGTH_SHORT).show();
                break;
            case 1:
                Toast.makeText(c, message, Toast.LENGTH_LONG).show();
                break;
            default:
                Toast.makeText(c,"Invalid Toast ID", Toast.LENGTH_LONG).show();
                break;
        }
    }
}
