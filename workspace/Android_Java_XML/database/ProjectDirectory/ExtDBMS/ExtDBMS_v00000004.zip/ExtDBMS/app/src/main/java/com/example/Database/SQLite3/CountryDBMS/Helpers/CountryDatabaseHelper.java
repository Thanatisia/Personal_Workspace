package com.example.Database.SQLite3.CountryDBMS.Helpers;

import android.app.Application;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Environment;

import java.io.File;

public class CountryDatabaseHelper extends SQLiteOpenHelper {
    /* Global variables */
    public static Application app = new Application();

    public static File sdcard = Environment.getExternalStorageDirectory();
    public static String cwd = sdcard.getPath();

    SQLiteDatabase.CursorFactory factory;

    /* Database Properties */
    //Table Name
    public static final String TABLE_NAME = "COUNTRIES";

    //Table Columns
    public static final String ROW_ID = "_id";   //The Row Number of the table
    public static final String ROW_ID_PARAMS = "INTEGER PRIMARY KEY AUTOINCREMENT";
    public static final String SUBJECT = "subject";
    public static final String SUBJECT_PARAMS = "TEXT NOT NULL";
    public static final String DESCRIPTION = "description";
    public static final String DESCRIPTION_PARAMS = "TEXT";

    //Database Name
    public static final String DB_NAME = "CountryDBMS";
    public static final String DB_EXTENSION = "db";
    public static final String DB_FULL_NAME = DB_NAME + "." + DB_EXTENSION;

    //Database Path
    public static final String DB_PATH = cwd + "\\";
    public static final String DB_FULL_OUTPUT_PATH = DB_PATH + DB_FULL_NAME;

    //Database Version
    static final int DB_VERSION = 1;

    /* Queries */
    private static final String CREATE_TABLE = "CREATE TABLE IF NOT EXISTS" + " " + TABLE_NAME +
            "(" +
                ROW_ID + " " + ROW_ID_PARAMS  + "," + " " +
                SUBJECT + " " + SUBJECT_PARAMS + "," + " " +
                DESCRIPTION + " " + DESCRIPTION_PARAMS +
            ");";

    private static final String DROP_TABLE = "DROP TABLE IF EXISTS" + " " + TABLE_NAME;

    /* Create Class Constructor */

    //Designs the Database we will be using according to the Activity
    public CountryDatabaseHelper(Context context)
    {
        /*
        Android SQLite3 only supports internal storage
        - to use internal storage, must - onCreate() - copy the external storage file to the internal storage directory
         */
        super(context, DB_FULL_NAME, null, DB_VERSION);
        //super(context, DB_FULL_OUTPUT_PATH, null, DB_VERSION);
    }

    /* Called when there is no database - and the application needs one - automatically executes this if doesnt exist
    * Generally - execute the CREATE TABLE SQL to fill it with data
    * */
    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_TABLE);
    }

    /* Called when the schema version we need does not match the schema version of the database
    - Passes us a
        - SQLiteDatabase object
        - int old version numbers
        - int new version numbe
    - can figure out the best way to convert the database from the old schema to the new schema
     */
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL(DROP_TABLE);
        onCreate(db);
    }
}
