package com.example.Externals;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.arch.core.util.Function;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.lang.reflect.Array;

public class utilities {
    /*
    External classes and functions
    - must put [public]
     */
    public void alert(Context c, String message, Integer LENGTH_ID)
    {
        switch(LENGTH_ID)
        {
            case 0:
                Toast.makeText(c, message, Toast.LENGTH_SHORT).show();
                break;
            case 1:
                Toast.makeText(c, message, Toast.LENGTH_LONG).show();
                break;
            default:
                Toast.makeText(c,"Invalid Toast ID", Toast.LENGTH_LONG).show();
                break;
        }
    }

    public AlertDialog.Builder alert_dialog_build(Context c, String label_title, View view)
    {
        /* Create a popup for MENU_DEBUG : Validate role */
        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(c);

        // set prompts.xml to alertdialog builder
        alertDialogBuilder.setView(view);
        alertDialogBuilder.setTitle(label_title);

        return alertDialogBuilder;
    }

    public void alert_dialog_set_cancelable(AlertDialog.Builder builder_object, boolean cancelable)
    {
        builder_object.setCancelable(cancelable);
    }

    public AlertDialog create_alertdialog(AlertDialog.Builder alertDialogBuilder)
    {
        AlertDialog alertdialog = alertDialogBuilder.create();
        return alertdialog;
    }
    public void start_alertdialog(AlertDialog alertDialog)
    {
        alertDialog.show();
    }

    public AlertDialog create_and_start_alertdialog(AlertDialog.Builder alertDialogBuilder)
    {
        AlertDialog alertDialog = alertDialogBuilder.create();
        alertDialog.show();
        return alertDialog;
    }

    public String read_from_file(Context c, String file_directory, String read_file_name)
    {
        String text_from_file = "";
        File read_file = new File(file_directory, read_file_name);
        if (!read_file.exists()) {
            try {
                read_file.createNewFile();
            } catch (IOException e) {
                e.printStackTrace();
                Toast.makeText(c, "IO Exception Caught:" + e.getMessage().toString(), Toast.LENGTH_LONG).show();
            } catch (Exception e) {
                Toast.makeText(c, "General Exception Caught:" + e.getMessage().toString(), Toast.LENGTH_LONG).show();
            }
        }
        else {
            StringBuilder sb = new StringBuilder();
            FileReader fr;
            //Read data from file
            BufferedReader reader = null;
            try {
                fr = new FileReader(read_file);
                reader = new BufferedReader(fr);
                String line;
                while ((line = reader.readLine()) != null) {
                    text_from_file += line.toString();
                    text_from_file += "\n";
                }
                reader.close();
            } catch (IOException e) {
                e.printStackTrace();
                Toast.makeText(c, "IO Exception Caught:" + e.getMessage().toString(), Toast.LENGTH_LONG).show();
            } catch (Exception e) {
                Toast.makeText(c, "General Exception Caught:" + e.getMessage().toString(), Toast.LENGTH_LONG).show();
            }
        }
        return text_from_file;
    }
}
