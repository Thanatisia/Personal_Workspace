package com.example.extdbms;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.view.menu.MenuBuilder;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Resources;
import android.os.Bundle;
import android.view.ContextMenu;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import com.example.Externals.app_control;
import com.example.Externals.globals;
import com.example.Externals.utilities;
import com.example.Externals.list_utility;
import com.example.Externals.menu_utility;
import com.example.Security.security_management;
import com.example.Security.settings;

public class MainActivity extends AppCompatActivity {

    /* Application Environment Variables*/
    Context c = this;
    Activity a = this;

    /* Initialize list of roles */

    /* Library Imports */
    utilities util;
    globals gl;
    list_utility list_ctrl;
    app_control appCtrl;
    menu_utility menuCtrl;
    security_management securityCtrl;
    settings application_settings;

    /* SharedPreferences */
    SharedPreferences pref;
    SharedPreferences.Editor editor;
    String sharedPreferences_key = "MyPreferences";
    int mode = 0;

    String KEY_BUILD_TYPE = "build_type";
    String build_type;

    /* Menu */
    Menu homepage_menu;
    MenuInflater inflater;
    int MENU_DEBUG = 0;
    int MENU_ENABLE_MODE_DEBUG = 1;
    int MENU_DEBUG_ENV_DETAILS = 2;
    int MENU_RELEASE = 3;


    /* Database ListView */
    private ListView lv_Rows;
    private ArrayAdapter<String> listAdapter;
    /* Lists */
    List<String> db_row_list;

    /* TextView */
    TextView tv_db_opened;

    /* EditText */
    EditText et_db_name;
    EditText et_value_input;

    /* Buttons */
    Button btn_openDB;
    Button btn_insertRow;
    Button btn_editValue;
    Button btn_deleteValue;
    Button btn_deleteRow;
    Button btn_save_to_text_file;

    /* Global variables */
    String tmp_val_str = "";
    int tmp_val_str_len = 0;
    String tmp = "";
    int tmp_int = 0;
    int total_rows = 0;

    /* Constants */
    public static final int LENGTH_SHORT = 0;
    public static final int LENGTH_LONG = 1;

    /* Database Columns */
    int rowID = 0;
    String db_name = "";
    String table_name = "";
    List<Integer> db_row_ID;
    List<String> db_row_name;
    List<String> db_table_name;

    /* ListView Variables */
    int selected_item_row_number = -1;
    String selected_item_row_value_token = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        /* Initialize classes */
        init();

        /* Set Application settings */
        a.setTitle(application_settings.default_title);

        /* Look for SharedPreferences */

        // SharedPreferences 1. Build_Type : DEBUG or RELEASE
        build_type = pref.getString(KEY_BUILD_TYPE, null); //Retrieving SharedPreferences
        if(securityCtrl.get_build_type() != build_type && build_type != null)
        {
            securityCtrl.set_role(build_type);
        }
        else
        {
            Toast.makeText(c, securityCtrl.get_build_type(), Toast.LENGTH_LONG).show();
        }
        util.alert(c, "Welcome back," + " " + securityCtrl.get_build_type(), 1);



        /* Column Lists */
        db_table_name = new ArrayList<String>();
        db_row_ID = new ArrayList<Integer>();
        db_row_name = new ArrayList<String>();

        /* Button Initialize */
        btn_openDB = (Button)findViewById(R.id.btn_open_database);
        btn_insertRow = (Button)findViewById(R.id.btn_insert_row);
        btn_editValue = (Button)findViewById(R.id.btn_edit_value);
        btn_deleteRow = (Button)findViewById(R.id.btn_delete_row);
        btn_deleteValue = (Button)findViewById(R.id.btn_delete_value);
        btn_save_to_text_file = (Button)findViewById(R.id.btn_output_to_file);

        /* TextView Initialize */
        tv_db_opened = (TextView)findViewById(R.id.tv_db_opened);

        /* EditText Initialize */
        et_db_name = (EditText)findViewById(R.id.et_database_name);
        et_value_input = (EditText)findViewById(R.id.et_Value_Input);

        lv_Rows = (ListView) findViewById(R.id.lv_database_board);
        db_row_list = new ArrayList<String>();
        listAdapter = new ArrayAdapter<String>(this, R.layout.row_details);
        //listAdapter.add("Row 1"); /* Add value into List */
        lv_Rows.setAdapter(listAdapter); /* Put all data in the List into lv_Rows */


        /* "Open" Database */
        btn_openDB.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                /* Get Text from EditText */
                tmp_val_str = et_db_name.getText().toString();
                tmp_val_str_len = tmp_val_str.length(); /* Get the length of EditText String */

                /* Validate: Only run if length is more than 0 */
                if(tmp_val_str_len > 0)
                {
                    db_name = tmp_val_str;
                    tv_db_opened.setText("Database Opened : " + db_name); //Append to [Database Opened: ]
                }
                else
                {
                    util.alert(c,
                            "TextBox Entry [Database Name] has no text",
                            0);
                }
            }
        });

        /* Insert into ListAdapter */
        btn_insertRow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                /* Get Text from EditText */
                tmp_val_str = et_value_input.getText().toString();
                tmp_val_str_len = tmp_val_str.length(); /* Get the length of EditText String */

                /* Validate: Only run if length is more than 0 */
                if(tmp_val_str_len > 0)
                {
                    if(db_name != null && !db_name.isEmpty() && !db_name.equals("null"))
                    {
                        rowID++;
                        //listAdapter.add(rowID + " " + "|" + " " + tmp_val_str);
                        db_row_ID.add(rowID);
                        db_row_name.add(tmp_val_str);

                        /* Replace rowID with the size of occupied elements */
                        db_row_ID.clear();
                        for (int i = 0; i < db_row_name.size(); i++) {
                            db_row_ID.add(i);
                        }

                        total_rows = db_row_ID.size();

                        /* Clear before adding */
                        listAdapter.clear();
                        for (int i = 0; i < db_row_ID.size(); i++) {
                            listAdapter.add(db_row_ID.get(i) + " " + "|" + " " + db_row_name.get(i));
                        }
                    }
                    else
                    {
                        util.alert(c,
                                "Database not opened",
                                1
                        );
                    }
                }
                else
                {
                    util.alert(c,
                            "TextBox Entry [Values] has no text",
                            0);
                }
            }
        });

        /* Edit ArrayLists */
        btn_editValue.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                tmp_val_str = et_value_input.getText().toString();
                tmp_val_str_len = tmp_val_str.length(); /* Get the length of EditText String */

                if(selected_item_row_number < 0 && selected_item_row_value_token.equals(""))
                {
                    util.alert(c, "A row has not yet been selected", 1);
                }
                else {
                    tmp = db_row_name.get(selected_item_row_number);

                    if (tmp_val_str_len > 0) {
                        db_row_name.set(selected_item_row_number, tmp_val_str);

                        total_rows = db_row_ID.size();

                        /* Clear before replacing with updated values */
                        listAdapter.clear();
                        for(int i=0; i < db_row_ID.size(); i++)
                        {
                            listAdapter.add(db_row_ID.get(i) + " " + "|" + " " + db_row_name.get(i));
                        }
                    }
                    else
                    {
                        util.alert(c, "TextBox Entry [Values] has no text - Nothing to edit.",1);
                    }
                }
            }
        });

        /* Clear a value */
        btn_deleteValue.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(selected_item_row_value_token.equals(""))
                {
                    util.alert(c, "A row has not yet been selected", 1);
                }
                else {
                    tmp = db_row_name.get(selected_item_row_number);

                    db_row_name.set(selected_item_row_number, "");

                    total_rows = db_row_ID.size();

                    /* Clear before replacing with updated values */
                    listAdapter.clear();
                    for(int i=0; i < db_row_ID.size(); i++) {
                        if (db_row_name.get(i).length() == 0) {
                            listAdapter.add(db_row_ID.get(i) + " " + "|" + " " + "<EMPTY>");
                        } else {
                            listAdapter.add(db_row_ID.get(i) + " " + "|" + " " + db_row_name.get(i));
                        }
                    }
                }
            }
        });

        /* Delete an entire row - Remove from arraylist */
        btn_deleteRow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(selected_item_row_number < 0 && selected_item_row_value_token.equals(""))
                {
                    util.alert(c, "A row has not yet been selected", 1);
                }
                else {
                    tmp_int = db_row_ID.get(selected_item_row_number);

                    db_row_ID.remove(selected_item_row_number);
                    db_row_name.remove(selected_item_row_number);

                    rowID--; //Remove 1 after deleting

                    total_rows = db_row_ID.size();

                    /* Clear before replacing with updated values */
                    db_row_ID.clear();
                    for(int i=0; i < db_row_name.size(); i++) {
                        /* Replace rowID with the size of occupied elements */
                        db_row_ID.add(i);
                    }

                    listAdapter.clear();
                    for(int i=0; i < db_row_ID.size(); i++)
                    {
                        listAdapter.add(db_row_ID.get(i) + " " + "|" + " " + db_row_name.get(i));
                    }

                    /* Reset the tokens after deletion - Seized to exist */
                    selected_item_row_number = -1;
                    selected_item_row_value_token = "";
                }
            }
        });

        /* Save to text file */
        btn_save_to_text_file.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                util.alert(c, "TODO - Save Text", LENGTH_LONG);
            }
        });

        /* When Listview Item is clicked */
        lv_Rows.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                //alert(listAdapter.getItem(position).toString(), 1);
                selected_item_row_number = position;
                selected_item_row_value_token = db_row_name.get(position);
                util.alert(c,
                        "Selected" + " " + ":" + " " + "\n" +
                                "[" + " " + "\n" +
                                "   Row   ID" + " " + ":" + " " + db_row_ID.get(position).toString() + "\n" +
                                "   Row Name" + " " + ":" + " " + db_row_name.get(position) + "\n" +
                                "]",
                        1);
            }
        });

        /* When Listview is long clicked
        * Open ActionMenu
        *
        */
        lv_Rows.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                util.alert(c,
                        listAdapter.toString(),
                        1);
                return false;
            }
        });

        lv_Rows.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                //alert("Long Click:" + listAdapter.getItem(position).toString(), 1);
                util.alert(c,
                        "Row ID" + " " + ":" + " " + db_row_ID.get(position).toString() + "\n" +
                        "Row Name" + " " + ":" + " " + db_row_name.get(position).toString(),
                        1);
                return true;
                //return false;
            }
        });
    }

    void init()
    {
        util = new utilities();
        gl = new globals();
        list_ctrl = new list_utility();
        appCtrl = new app_control();
        menuCtrl = new menu_utility();
        securityCtrl = new security_management();
        application_settings = new settings();

        /* Initializing Shared Preferences */
        pref = getApplicationContext().getSharedPreferences(sharedPreferences_key, mode);
        editor = pref.edit();
    }

    void tests()
    {
        /* Testing Globals */
        List<String> env_list = new ArrayList<>();
        env_list = appCtrl.retrieve_program_details(a);
        String app_title = list_ctrl.string_list_get_element(env_list, 0);
        String package_name = list_ctrl.string_list_get_element(env_list, 1);
        util.alert(c,
                "Home path: " + gl.cwd + "\n" +
                "Environment: " + env_list.toString(),
                1);
    }

    public boolean validate_debug(String uInput, String KEYWORD_PASS)
    {
        boolean token = false;
        if(uInput != null && !uInput.isEmpty() && !uInput.equals("null") && uInput.equals(KEYWORD_PASS))
        {
            token = true;
        }
        else
        {
            token = false;
        }
        return token;
    }

    /* Menu Functions
    * public boolean onCreateOptionsMenu(Menu menu) : To inflate and display the menu
    * public boolean onOptionsItemSelected(@NonNull MenuItem item) : Functions to execute when item is selected from Menu
    * */
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        /* Initialize Menu */
        // Enable Menu Icon Display
        menuCtrl.enable_menu_icon(menu); //Enable display of menu icon

        // Designing Menu Items
        if(securityCtrl.check_build_type() == 1) //Enable Debug menu if is DEBUG
        {
            MenuItem menu_design_debug = menuCtrl.add_menu(menu, 0, MENU_DEBUG, 0, "DEBUGGER");
            menuCtrl.set_icon(menu_design_debug, R.mipmap.ic_launcher_round);

            MenuItem menu_design_release = menuCtrl.add_menu(menu, 0, MENU_RELEASE, 0, "Debugger Logout");
            menuCtrl.set_icon(menu_design_release, R.mipmap.ic_launcher_round);

            MenuItem menu_design_env_details = menuCtrl.add_menu(menu, 0, MENU_DEBUG_ENV_DETAILS, 0, getResources().getString(R.string.main_menu_1));
            menuCtrl.set_icon(menu_design_env_details, R.mipmap.launcher_main_sqlite_logo);
        }
        else
        {
            MenuItem menu_design = menuCtrl.add_menu(menu, 0, MENU_ENABLE_MODE_DEBUG, 0, "Enable Debug Mode");
            menuCtrl.set_icon(menu_design, R.mipmap.ic_launcher_round);
        }

        // Inflating Menu - preparing for display
        inflater = getMenuInflater();
        inflater.inflate(R.menu.main, menu); /* Inflate Menu */
        //return super.onCreateOptionsMenu(menu);
        return true;
    }
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        /* Handle Item Selection */
        //Using switch
//        switch(item.getItemId())
//        {
//            case R.id.menu_env_details:
//                tests();
//                return true;
//            default:
//                return super.onOptionsItemSelected(item);
//        }
        //Using IF else
        int id = item.getItemId();
        if(id == MENU_DEBUG_ENV_DETAILS)
        {
            tests();
            return true;
        }
        else if(id == MENU_DEBUG) //DEBUGGER build_type role Menu item select
        {
            Toast.makeText(c, "Nice. \n You're in DEBUGGER", Toast.LENGTH_LONG).show();
            return true;
        }
        else if(id == MENU_ENABLE_MODE_DEBUG) //Login from RELEASE to DEBUGGER mode (Developer mode)
        {
            String OK_BUTTON_TEXT = "OK";
            final String KEYWORD_PASS = "GODMODE";
            String label_title = "Please enter your password:";
            boolean cancelable = false;
            /* Create a popup for MENU_DEBUG : Validate role */
//            AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(c);
//
//            final EditText et = new EditText(c);
//
//            // set prompts.xml to alertdialog builder
//            alertDialogBuilder.setView(et);
//            alertDialogBuilder.setTitle(label_title + " ");
//
//            // set dialog message
//            alertDialogBuilder.setCancelable(false).setPositiveButton("OK", new DialogInterface.OnClickListener() {
//                public void onClick(DialogInterface dialog, int id) {
//                    String uInput = et.getText().toString();
//                    if(uInput != null && !uInput.isEmpty() && !uInput.equals("null") && uInput.equals(KEYWORD_PASS))
//                    {
//                        util.alert(c, "Opening DEBUG Menu", 1);
//                    }
//                    else
//                    {
//                        util.alert(c, "Invalid password", 1);
//                    }
//                }
//            });
//            // create alert dialog
//            AlertDialog alertDialog = alertDialogBuilder.create();
//
//            // show it
//            alertDialog.show();

            final EditText et = new EditText(c);
            AlertDialog.Builder alertDialogBuilder = util.alert_dialog_build(c, label_title, et);   //Create Alert Dialog
            util.alert_dialog_set_cancelable(alertDialogBuilder, cancelable);                    //Set non-cancelable

            alertDialogBuilder.setPositiveButton(OK_BUTTON_TEXT, new DialogInterface.OnClickListener()    //Set Button and OK button
            {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    String uInput = et.getText().toString();
                    boolean token = validate_debug(uInput, KEYWORD_PASS);
                    if(token)
                    {
                        util.alert(c, "Opening DEBUG Menu", 1);
                        securityCtrl.set_role("DEBUG");
                        editor.putString(KEY_BUILD_TYPE,securityCtrl.get_build_type()); //Store String value to SharedPreferences
                        editor.commit(); //Like github and SQLite3 - you must commit to save the changes to SharedPreferences
                        Toast.makeText(c, securityCtrl.get_build_type(), Toast.LENGTH_LONG).show();
                        Intent refresh = new Intent(c, MainActivity.class);
                        startActivity(refresh);
                        finish();
                    }
                    else
                    {
                        util.alert(c, "Invalid password", 1);
                    }
                }
            });

            //create alert dialog and show
            util.create_and_start_alertdialog(alertDialogBuilder);
            return true;
        }
        else if(id == MENU_RELEASE) //Return back from DEBUG to RELEASE
        {
            //Clear SharedPreferences Data - build_type (aka KEY_BUILD_TYPE)
            securityCtrl.set_role("RELEASE");
            editor.remove(KEY_BUILD_TYPE); //Remove key from SharedPreferences - usually Logout, like $_SESSION in PHP - use .clear() to remove all data
            editor.commit(); //Like github and SQLite3 - you must commit to save the changes to SharedPreferences
            Toast.makeText(c, securityCtrl.get_build_type(), Toast.LENGTH_LONG).show();
            Intent refresh = new Intent(c, MainActivity.class);
            startActivity(refresh);
            finish();
            return true;
        }
        else if(id == R.id.menu_write_list_to_textfile)
        {
            util.alert(c, "Output List to File", 1);
            String out_file_name = db_name;
            String text_from_file = "";
            if(out_file_name != null && !out_file_name.isEmpty() && !out_file_name.equals("null"))
            {
                //Read file - get number lines
                text_from_file = util.read_from_file(c, gl.sdcard + "//", out_file_name);

                //Check Length
                int read_file_input_length = text_from_file.length();

                File out_file = new File(gl.sdcard + "//", out_file_name);
                if (!out_file.exists()) {
                    try {
                        out_file.createNewFile();
                    } catch (IOException e) {
                        e.printStackTrace();
                        util.alert(c, "IO Exception Caught:" + e.getMessage().toString(), 1);
                    } catch (Exception e) {
                        util.alert(c, "General Exception Caught:" + e.getMessage().toString(), 1);
                    }
                }

                //Create File Writer
                FileWriter fw;
                try {
                    fw = new FileWriter(out_file, true /* Append */);
                    BufferedWriter writer = new BufferedWriter(fw);
                    int tmp_i = 0;
                    String tmp_j = "";
                    //Write
                    for (int i = 0; i < db_row_ID.size(); i++) {
                        if(i == 0 && read_file_input_length > 0) //Exists
                        {
                            writer.write("\n");
                        }
                        writer.write(db_row_ID.get(i).toString());
                        writer.write("\n");
                        writer.write(db_row_name.get(i));
                        writer.write("\n");
                    }
                    writer.close();
                } catch (IOException e) {
                    e.printStackTrace();
                    util.alert(c, "IO Exception Caught:" + e.getMessage().toString(), 1);
                } catch (Exception e) {
                    util.alert(c, "General Exception Caught:" + e.getMessage().toString(), 1);
                }
            }
            else
            {
                util.alert(c, "Database not opened.",1);
            }

            return true;
        }
        else
        {
            return super.onOptionsItemSelected(item);
        }
        //return super.onOptionsItemSelected(item);
    }

}
