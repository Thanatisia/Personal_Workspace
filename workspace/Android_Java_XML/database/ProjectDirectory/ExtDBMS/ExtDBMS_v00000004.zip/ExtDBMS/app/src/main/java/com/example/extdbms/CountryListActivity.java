package com.example.extdbms;

import android.app.Activity;
import android.app.Application;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.os.Environment;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.Database.SQLite3.CountryDBMS.AddCountryActivity;
import com.example.Database.SQLite3.CountryDBMS.Helpers.CountryDBManager;
import com.example.Database.SQLite3.CountryDBMS.Helpers.CountryDatabaseHelper;
import com.example.Database.SQLite3.CountryDBMS.ModifyCountryActivity;

import com.example.Externals.file_utilities;
import com.example.Externals.globals;

public class CountryListActivity extends AppCompatActivity {
    /* Global variables */
    Context c = this;
    Activity a = this;
    Application app = new Application();
    public String private_data_directory;
    public String private_database_output_directory;
//    public String private_data_directory = getDataDir().toString(); //This is where the private data only accessible by root is located
//    public String private_database_output_directory = private_data_directory + "/" + "databases" + "/"; //This is where the SQLite3 file is located and where you have to copy from to your destination address to export the database and import


    /* Libraries */
    file_utilities fileUtil;
    globals gl;

    /* Database Variables */
    private CountryDBManager dbManager;
    private ListView lv_db;
    private SimpleCursorAdapter cursor_adapter; //To fill with Cursors

    /* Array filled with Column Names */
    final String[] from = new String[] {
            CountryDatabaseHelper.ROW_ID,
            CountryDatabaseHelper.SUBJECT,
            CountryDatabaseHelper.DESCRIPTION
    };

    final int[] to = new int[]{
            R.id.id,
            R.id.title,
            R.id.desc
    };

    /* Views */
    TextView tv_id;
    TextView tv_subject;
    TextView tv_description;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.fragment_emp_list);

        //Initialize
        init_views();
        init_libraries();
        init_paths();

        /* Database crashes on opening */
        try {
            dbManager = new CountryDBManager(c); //Create new instance of Database
            dbManager.open(); //Open Connection to Database
        }
        catch (Exception ex)
        {
            Toast.makeText(c, ex.getMessage(), Toast.LENGTH_LONG).show();
        }

        Cursor cursor = null;
        try {
            cursor = dbManager.fetch(); //Fetch data and put into cursor
        }
        catch (Exception ex)
        {
            Toast.makeText(c, ex.getMessage(), Toast.LENGTH_LONG).show();
        }

        lv_db = (ListView)findViewById(R.id.lv_db_contents);
        lv_db.setEmptyView(findViewById(R.id.empty));

        try {
            cursor_adapter = new SimpleCursorAdapter(c, R.layout.activity_country_view_record_file, cursor, from, to, 0); //Context, layout, cursor_with_data, from, to(new_data)
            cursor_adapter.notifyDataSetChanged(); //Notify if data changes
        }
        catch (Exception ex)
        {
            Toast.makeText(c, ex.getMessage(), Toast.LENGTH_LONG).show();
        }

        try {
            lv_db.setAdapter(cursor_adapter); //Fill ListView with data filled by the Cursor objects inside CursorAdapter
        }catch (Exception ex)
        {
            Toast.makeText(c, ex.getMessage(), Toast.LENGTH_LONG).show();
        }

        //OnClickListener for List items
        lv_db.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long viewId) {
                TextView idTextView = (TextView)findViewById(R.id.id);
                TextView titleTextView = (TextView)findViewById(R.id.title);
                TextView descTextView = (TextView)findViewById(R.id.desc);

                String id = idTextView.getText().toString();
                String title = titleTextView.getText().toString();
                String description = descTextView.getText().toString();

                Intent intent_modify = new Intent(CountryListActivity.this, ModifyCountryActivity.class);
                //Pass the extra data to the new class as Keys for modification
                intent_modify.putExtra("title", title);
                intent_modify.putExtra("desc", description);
                intent_modify.putExtra("id", id);
                startActivity(intent_modify);
            }
        });
    }

    void init_views()
    {
        tv_id = (TextView)findViewById(R.id.id);
        tv_subject = (TextView)findViewById(R.id.title);
        tv_description = (TextView)findViewById(R.id.desc);
    }

    void init_libraries()
    {
        fileUtil = new file_utilities();
        gl = new globals();
    }

    void init_paths()
    {
        private_data_directory = getDataDir().toString(); //This is where the private data only accessible by root is located
        private_database_output_directory = private_data_directory + "/" + "databases" + "/"; //This is where the SQLite3 file is located and where you have to copy from to your destination address to export the database and import
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.sqlite_db_menu, menu);
        //return super.onCreateOptionsMenu(menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.menu_add_record) {
            /*
            Add Records into Database
             */
            Intent add_member = new Intent(CountryListActivity.this, AddCountryActivity.class);
            startActivity(add_member);
            return true;
        }
        else if(id == R.id.menu_export_database)
        {
            /*
            Export Database from private directory to public accessible internal storage directory ("cwd")
             */
            Toast.makeText(c, String.format("Export from\n [ %1s ] and copy to\n [ %2s ]", private_database_output_directory, gl.cwd), Toast.LENGTH_LONG).show();
            return true;
        }
        else if(id == R.id.menu_import_database)
        {
            /*
            Import database from public accessible internal storage directory ("cwd") into private directory
                - overwrite current directory with new database
             */
            Toast.makeText(c, String.format("Import from\n [ %1s ] and copy into private directory\n [ %2s ], \n Overwrite the existing file", gl.cwd, private_database_output_directory), Toast.LENGTH_LONG).show();
            return true;
        }
        else {
            return super.onOptionsItemSelected(item);
        }
    }
}
