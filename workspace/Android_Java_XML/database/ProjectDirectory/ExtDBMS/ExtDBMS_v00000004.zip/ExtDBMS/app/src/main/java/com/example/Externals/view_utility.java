package com.example.Externals;

import android.content.Context;
import android.view.View;
import android.widget.Toast;

public class view_utility {
    public int VISIBLE = View.VISIBLE;
    public int INVISIBLE = View.INVISIBLE;
    public int GONE = View.GONE;

    public String set_visibility(Context c, View view_id, int visibility)
    {
        /* VISIBLE, INVISIBLE, GONE */
        String visibility_mode = "";
        if(visibility == GONE)
        {
            view_id.setVisibility(visibility);
            visibility_mode = "GONE";
        }
        else if(visibility == INVISIBLE)
        {
            view_id.setVisibility(visibility);
            visibility_mode = "INVISIBLE";
        }
        else if(visibility == VISIBLE)
        {
            view_id.setVisibility(visibility);
            visibility_mode = "VISIBLE";
        }
        else
        {
            visibility_mode = "Invalid";
//            Toast.makeText(c, String.format("Invalid visibility id - Please use either [%1s] or [%2s] or [%3s]", "View.VISIBLE", "View.INVISIBLE", "View.GONE"), Toast.LENGTH_LONG).show();
        }
        return visibility_mode;
    }
}
