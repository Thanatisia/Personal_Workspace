package com.example.extdbms;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Application;
import android.content.Context;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;

import java.util.ArrayList;
import java.util.List;

/* Externals Library
    1. app_control : Application Control
    - prog_title
    - package_name
    - retrieve_program_details(Activity a)
        etc.

 */
import com.example.Externals.app_control;
import com.example.Externals.globals;
import com.example.Externals.utilities;
import com.example.Externals.list_utility;
import com.example.Externals.menu_utility;
import com.example.Security.security_management;
import com.example.Security.settings;
import com.example.JSON.JSONParser;

public class DesignRoom extends AppCompatActivity {

    /* Application Environment Variables*/
    Context c = this;
    Activity a = this;
    Application app = new Application();
    Class cl = FileManagement.class;

    /* Initialize list of roles */

    /* Library Imports */
    utilities util;
    globals gl;
    list_utility list_ctrl;
    app_control appCtrl;
    menu_utility menuCtrl;
    security_management securityCtrl;
    settings application_settings;
    JSONParser jsonparser;

    /* SharedPreferences */
    SharedPreferences pref;
    SharedPreferences.Editor editor;
    String sharedPreferences_key = "MyPreferences";
    int mode = 0;

    String KEY_BUILD_TYPE = "build_type";
    String build_type;

    /* Menu */
    Menu homepage_menu;
    MenuInflater inflater;



    /* Database ListView */

    /* Lists */
    List<String> db_row_list;

    /* TextView */


    /* EditText */


    /* Buttons */

    /* Global variables */
    String tmp_val_str = "";
    int tmp_val_str_len = 0;
    String tmp = "";
    int tmp_int = 0;
    int total_rows = 0;

    /* JSON */
    String json_asset_text = "";
    String asset_json_path = "";
    public String config_file = "config.json";

    /* Constants */
    public static final int LENGTH_SHORT = 0;
    public static final int LENGTH_LONG = 1;
    public String APPLICATION_DATA_FOLDER_PATH;
    public String APPLICATION_DATA_FOLDER_PATH_CONFIG;

    /* Database Columns */
    int rowID = 0;
    String db_name = "";
    String table_name = "";
    List<Integer> db_row_ID;
    List<String> db_row_name;
    List<String> db_table_name;

    /* ListView Variables */
    int selected_item_row_number = -1;
    String selected_item_row_value_token = "";
    List<Object> selected_item_tokens = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_design_room);
        init_class();
        a.setTitle(String.format("%1s", "Design Room"));
    }

    void init_class()
    {
        util = new utilities();
        gl = new globals();
        list_ctrl = new list_utility();
        appCtrl = new app_control();
        menuCtrl = new menu_utility();
        securityCtrl = new security_management();
        application_settings = new settings();
        jsonparser = new JSONParser();
    }

    /* Menu Functions
     * public boolean onCreateOptionsMenu(Menu menu) : To inflate and display the menu
     * public boolean onOptionsItemSelected(@NonNull MenuItem item) : Functions to execute when item is selected from Menu
     * */
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        /* Initialize Menu */
        // Enable Menu Icon Display
        menuCtrl.enable_menu_icon(menu); //Enable display of menu icon

        // Inflating Menu - preparing for display
        inflater = getMenuInflater();
        inflater.inflate(R.menu.main, menu); /* Inflate Menu */
        //return super.onCreateOptionsMenu(menu);
        return true;
    }
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        /* Handle Item Selection */
        //Using switch
//        switch(item.getItemId())
//        {
//            case R.id.menu_env_details:
//                tests();
//                return true;
//            default:
//                return super.onOptionsItemSelected(item);
//        }
        //Using IF else
        int id = item.getItemId();
        return super.onOptionsItemSelected(item);
    }

    /* Back-button is pressed */
    @Override
    public void onBackPressed() {
        new AlertDialog.Builder(this)
                .setTitle("Really Exit?")
                .setMessage("Are you sure you want to exit?")
                .setNegativeButton(android.R.string.no, null)
                .setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface arg0, int arg1) {
                        DesignRoom.super.onBackPressed();
                    }
                }).create().show();
        //super.onBackPressed();
    }
}
