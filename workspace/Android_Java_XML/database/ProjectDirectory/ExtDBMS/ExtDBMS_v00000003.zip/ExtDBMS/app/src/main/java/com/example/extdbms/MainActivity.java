package com.example.extdbms;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.SubMenu;
import android.widget.TextView;
import android.widget.Toast;

/* Externals Library
    1. app_control : Application Control
    - prog_title
    - package_name
    - retrieve_program_details(Activity a)
        etc.

 */
import com.example.Externals.app_control;
import com.example.Externals.globals;
import com.example.Externals.utilities;
import com.example.Externals.list_utility;
import com.example.Externals.menu_utility;
import com.example.Security.security_management;
import com.example.Security.settings;
import com.example.JSON.JSONParser;
import com.example.Externals.os_utility; /* Operating Systems Utility */

public class MainActivity extends AppCompatActivity {

    /* Application Environment Variables*/
    Context c = this;
    Activity a = this;
    //Application app = new Application();
    Class cl = MainActivity.class;

    /* Initialize list of roles */

    /* Library Imports */
    utilities util;
    globals gl;
    list_utility list_ctrl;
    app_control appCtrl;
    menu_utility menuCtrl;
    security_management securityCtrl;
    settings application_settings;
    JSONParser jsonparser;
    os_utility osUtil;

    /* SharedPreferences */
    SharedPreferences pref;
    SharedPreferences.Editor editor;
    String sharedPreferences_key = "MyPreferences";

    String KEY_BUILD_TYPE = "build_type";
    String build_type;
    String SP_KEY_PERMISSION_WRITE_EXTERNAL_STORAGE = "PERMISSION_WRITE_EXTERNAL_STORAGE";
    String SP_KEY_PERMISSION_READ_EXTERNAL_STORAGE = "PERMISSION_READ_EXTERNAL_STORAGE";
    int mode = 0;

    /* Menu */
    Menu homepage_menu;
    MenuInflater inflater;
    public int MENU_ACTIVITIES = 0;
    public int SUBMENU_FileMgmt = 1;
    public int SUBMENU_DESIGNROOM = 2;
    public int GROUP_ACTIVITIES = 0;

    /* Permissions */
    private static final int REQUEST_CODE_READ_EXTERNAL_STORAGE = 100;
    String PERMISSION_WRITE_EXTERNAL_STORAGE_STATUS = "DENIED";
    String PERMISSION_READ_EXTERNAL_STORAGE_STATUS = "DENIED";

    /* Views */
    TextView tv_permissions_readExternalStorage;
    TextView tv_permissions_writeExternalStorage;
    String DEFAULT_TEXT_TV_READ_EXTERNAL_STORAGE;
    String DEFAULT_TEXT_TV_WRITE_EXTERNAL_STORAGE;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //Initialize
        init_class(); //Classes - utilities etc.
        init_views(); //Labels, Buttons etc
        init_sharedpreferences();

        //Set Properties
        a.setTitle("Main Activity");

        //Get default properties
        DEFAULT_TEXT_TV_READ_EXTERNAL_STORAGE = tv_permissions_readExternalStorage.getText().toString();
        DEFAULT_TEXT_TV_WRITE_EXTERNAL_STORAGE = tv_permissions_writeExternalStorage.getText().toString();

        //Check permission
        if(ContextCompat.checkSelfPermission(c, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED)
        {
            //Permission Enabled
            PERMISSION_READ_EXTERNAL_STORAGE_STATUS = "GRANTED";
            PERMISSION_WRITE_EXTERNAL_STORAGE_STATUS = "GRANTED";
            tv_permissions_readExternalStorage.setText(DEFAULT_TEXT_TV_READ_EXTERNAL_STORAGE + PERMISSION_READ_EXTERNAL_STORAGE_STATUS);
            tv_permissions_writeExternalStorage.setText(DEFAULT_TEXT_TV_WRITE_EXTERNAL_STORAGE + PERMISSION_WRITE_EXTERNAL_STORAGE_STATUS);

            editor.putString(SP_KEY_PERMISSION_WRITE_EXTERNAL_STORAGE, PERMISSION_WRITE_EXTERNAL_STORAGE_STATUS); //Store String value to SharedPreferences
            editor.putString(SP_KEY_PERMISSION_READ_EXTERNAL_STORAGE, PERMISSION_READ_EXTERNAL_STORAGE_STATUS);
            editor.commit(); //Like github and SQLite3 - you must commit to save the changes to SharedPreferences
        }
        else
        {
            PERMISSION_READ_EXTERNAL_STORAGE_STATUS = "DENIED";
            PERMISSION_WRITE_EXTERNAL_STORAGE_STATUS = "DENIED";
            tv_permissions_readExternalStorage.setText(DEFAULT_TEXT_TV_READ_EXTERNAL_STORAGE + PERMISSION_READ_EXTERNAL_STORAGE_STATUS);
            tv_permissions_writeExternalStorage.setText(DEFAULT_TEXT_TV_WRITE_EXTERNAL_STORAGE + PERMISSION_WRITE_EXTERNAL_STORAGE_STATUS);

            editor.putString(SP_KEY_PERMISSION_WRITE_EXTERNAL_STORAGE, PERMISSION_WRITE_EXTERNAL_STORAGE_STATUS); //Store String value to SharedPreferences
            editor.putString(SP_KEY_PERMISSION_READ_EXTERNAL_STORAGE, PERMISSION_READ_EXTERNAL_STORAGE_STATUS);
            editor.commit(); //Like github and SQLite3 - you must commit to save the changes to SharedPreferences

            //Permission not enabled
            ActivityCompat.requestPermissions(a,
                    new String[]{
                            Manifest.permission.READ_EXTERNAL_STORAGE
                    },
                    REQUEST_CODE_READ_EXTERNAL_STORAGE
            );
        }
    }

    void init_class()
    {
        util = new utilities();
        gl = new globals();
        list_ctrl = new list_utility();
        appCtrl = new app_control();
        menuCtrl = new menu_utility();
        securityCtrl = new security_management();
        application_settings = new settings();
        jsonparser = new JSONParser();
        osUtil = new os_utility();
    }

    void init_views()
    {
        tv_permissions_readExternalStorage = (TextView)findViewById(R.id.tv_check_permission_read_external_storage);
        tv_permissions_writeExternalStorage = (TextView)findViewById(R.id.tv_check_permission_write_external_storage);
    }

    void init_sharedpreferences()
    {
        /* Initializing Shared Preferences */
        pref = getApplicationContext().getSharedPreferences(sharedPreferences_key, mode);
        editor = pref.edit();
    }

    /* Permissions */
    //Override - IF permission was not granted and requested for permission - results checking
    //Check if granted or denied
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if(requestCode == REQUEST_CODE_READ_EXTERNAL_STORAGE)
        {
            if(grantResults[0] == PackageManager.PERMISSION_GRANTED) //If result of the request is that permission granted - permission granted
            {
                PERMISSION_READ_EXTERNAL_STORAGE_STATUS = "GRANTED";
                PERMISSION_WRITE_EXTERNAL_STORAGE_STATUS = "GRANTED";
                util.alert(c, String.format("READ EXTERNAL STORAGE Permission Status : [%1s]", "Permission Granted"),1 );
                tv_permissions_readExternalStorage.setText(DEFAULT_TEXT_TV_READ_EXTERNAL_STORAGE + PERMISSION_READ_EXTERNAL_STORAGE_STATUS);
                tv_permissions_writeExternalStorage.setText(DEFAULT_TEXT_TV_WRITE_EXTERNAL_STORAGE + PERMISSION_WRITE_EXTERNAL_STORAGE_STATUS);

                //Set to SharedPreferences
                editor.putString(SP_KEY_PERMISSION_WRITE_EXTERNAL_STORAGE, PERMISSION_WRITE_EXTERNAL_STORAGE_STATUS); //Store String value to SharedPreferences
                editor.putString(SP_KEY_PERMISSION_READ_EXTERNAL_STORAGE, PERMISSION_READ_EXTERNAL_STORAGE_STATUS);
                editor.commit(); //Like github and SQLite3 - you must commit to save the changes to SharedPreferences
            }
            else //Permission denied
            {
                PERMISSION_READ_EXTERNAL_STORAGE_STATUS = "DENIED";
                PERMISSION_WRITE_EXTERNAL_STORAGE_STATUS = "DENIED";
                util.alert(c, String.format("READ EXTERNAL STORAGE Permission Status : [%1s]", "Permission Denied"),1 );
                tv_permissions_readExternalStorage.setText(DEFAULT_TEXT_TV_READ_EXTERNAL_STORAGE + PERMISSION_READ_EXTERNAL_STORAGE_STATUS);
                tv_permissions_writeExternalStorage.setText(DEFAULT_TEXT_TV_WRITE_EXTERNAL_STORAGE + PERMISSION_WRITE_EXTERNAL_STORAGE_STATUS);

                //Set to SharedPreferences
                editor.putString(SP_KEY_PERMISSION_WRITE_EXTERNAL_STORAGE,PERMISSION_WRITE_EXTERNAL_STORAGE_STATUS); //Store String value to SharedPreferences
                editor.putString(SP_KEY_PERMISSION_READ_EXTERNAL_STORAGE, PERMISSION_READ_EXTERNAL_STORAGE_STATUS);
                editor.commit(); //Like github and SQLite3 - you must commit to save the changes to SharedPreferences
            }
        }
    }

    /* Menu Functions
     * public boolean onCreateOptionsMenu(Menu menu) : To inflate and display the menu
     * public boolean onOptionsItemSelected(@NonNull MenuItem item) : Functions to execute when item is selected from Menu
     * */
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        /* Initialize Menu */
        // Enable Menu Icon Display
        menuCtrl.enable_menu_icon(menu); //Enable display of menu icon

        menu.addSubMenu(Menu.NONE, MENU_ACTIVITIES, Menu.NONE, "Activities");
        /* Create Menu with SubMenu */
        SubMenu submenu_activities = menu.findItem(MENU_ACTIVITIES).getSubMenu();
        submenu_activities.setIcon(R.mipmap.launcher_main_sqlite_logo);

        /* Clear all headers */
        submenu_activities.clear();
        /* Add SubMenu items to Menu with SubMenu */
        submenu_activities.add(GROUP_ACTIVITIES, SUBMENU_FileMgmt, 0, "File Management");
        submenu_activities.add(GROUP_ACTIVITIES, SUBMENU_DESIGNROOM, 0, "Design Room");

        // Inflating Menu - preparing for display
        inflater = getMenuInflater();
        inflater.inflate(R.menu.main, menu); /* Inflate Menu */
        //return super.onCreateOptionsMenu(menu);
        return true;
    }
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        /* Handle Item Selection */
        //Using switch
//        switch(item.getItemId())
//        {
//            case R.id.menu_env_details:
//                tests();
//                return true;
//            default:
//                return super.onOptionsItemSelected(item);
//        }
        //Using IF else
        int id = item.getItemId();
        if(id == SUBMENU_FileMgmt)
        {
            Intent sqlite3DBMS = new Intent(c, FileManagement.class);
            startActivity(sqlite3DBMS);
            finish();
            return true;
        }
        else if(id == SUBMENU_DESIGNROOM)
        {
            Intent designRoom = new Intent(c, DesignRoom.class);
            startActivity(designRoom);
            finish();
            return true;
        }
        else if(id==R.id.menu_check_permissions)
        {
            //String permission_read_external_storage = tv_permissions_readExternalStorage.getText().toString();
            //String permission_write_external_storage = tv_permissions_writeExternalStorage.getText().toString();

            //Retrieving SharedPreferences
            String permission_read_external_storage = pref.getString(SP_KEY_PERMISSION_READ_EXTERNAL_STORAGE, null);
            String permission_write_external_storage = pref.getString(SP_KEY_PERMISSION_WRITE_EXTERNAL_STORAGE, null);

//            if(permission_read_external_storage != PERMISSION_READ_EXTERNAL_STORAGE_STATUS)
//            {
//                util.alert(c,
//                        String.format(
//                                "Please restart your application"
//                        ),
//                        1);
//            }
//            else {
//
//            }
            util.alert(c,
                    String.format(
                            "Permission [Write External Storage] Status : [%1s]\nPermission [Read External Storage] Status : [%2s] ",
                            permission_read_external_storage, permission_write_external_storage
                    ),
                    1);
            return true;
        }
        else
        {
            return super.onOptionsItemSelected(item);
        }
        //return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onStart() {
        /* When starts */
        int version = Integer.parseInt(osUtil.version_codes.get(28).toString());
        if(osUtil.check_build_version(version) == 1) /* SDK_INT < 14 */
        {
            /* If Build Version of the SDK is more than or equals to v14 (ICE CREAM SANDWICH) */
            util.alert(c, String.format("Less than [%1s]",osUtil.get_build_version()), 1);
        }
        else
        {
            util.alert(c, String.format("More than or equals to [%1s]", osUtil.get_build_version()), 1);
        }
        super.onStart();
    }

    @Override
    protected void onStop() {
        super.onStop();
    }

    @Override
    protected void onRestart() {
        super.onRestart();
    }

    @Override
    protected void onPause() {
        super.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
    }

    /* Back-button is pressed */
    @Override
    public void onBackPressed() {
        new AlertDialog.Builder(this)
                .setTitle("Really Exit?")
                .setMessage("Are you sure you want to exit?")
                .setNegativeButton(android.R.string.no, null)
                .setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface arg0, int arg1) {
                        MainActivity.super.onBackPressed();
                    }
                }).create().show();
        //super.onBackPressed();
    }
}
