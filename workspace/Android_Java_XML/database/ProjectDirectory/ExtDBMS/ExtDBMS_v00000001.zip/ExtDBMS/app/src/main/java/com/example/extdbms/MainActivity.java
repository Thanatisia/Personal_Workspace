package com.example.extdbms;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.bluetooth.BluetoothDevice;
import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

import com.example.Externals.utilities;

public class MainActivity extends AppCompatActivity {

    /* Application Environment Variables*/
    Context c = this;
    Activity a = this;


    /* Database ListView */
    private ListView lv_Rows;
    private ArrayAdapter<String> listAdapter;
    /* Lists */
    List<String> db_row_list;

    /* TextView */
    TextView tv_db_opened;

    /* EditText */
    EditText et_db_name;
    EditText et_value_input;

    /* Buttons */
    Button btn_openDB;
    Button btn_insertRow;
    Button btn_editValue;
    Button btn_deleteValue;
    Button btn_deleteRow;
    Button btn_save_to_text_file;

    /* Global variables */
    String tmp_val_str = "";
    int tmp_val_str_len = 0;
    String tmp = "";
    int tmp_int = 0;
    int total_rows = 0;

    /* Constants */
    public static final int LENGTH_SHORT = 0;
    public static final int LENGTH_LONG = 1;

    /* Database Columns */
    int rowID = 0;
    String db_name = "";
    String table_name = "";
    List<Integer> db_row_ID;
    List<String> db_row_name;
    List<String> db_table_name;

    /* ListView Variables */
    int selected_item_row_number = -1;
    String selected_item_row_value_token = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        /* Initialize classes */
        final utilities util = new utilities();

        /* Column Lists */
        db_table_name = new ArrayList<String>();
        db_row_ID = new ArrayList<Integer>();
        db_row_name = new ArrayList<String>();

        /* Button Initialize */
        btn_openDB = (Button)findViewById(R.id.btn_open_database);
        btn_insertRow = (Button)findViewById(R.id.btn_insert_row);
        btn_editValue = (Button)findViewById(R.id.btn_edit_value);
        btn_deleteRow = (Button)findViewById(R.id.btn_delete_row);
        btn_deleteValue = (Button)findViewById(R.id.btn_delete_value);
        btn_save_to_text_file = (Button)findViewById(R.id.btn_output_to_file);

        /* TextView Initialize */
        tv_db_opened = (TextView)findViewById(R.id.tv_db_opened);

        /* EditText Initialize */
        et_db_name = (EditText)findViewById(R.id.et_database_name);
        et_value_input = (EditText)findViewById(R.id.et_Value_Input);

        lv_Rows = (ListView) findViewById(R.id.lv_database_board);
        db_row_list = new ArrayList<String>();
        listAdapter = new ArrayAdapter<String>(this, R.layout.row_details);
        //listAdapter.add("Row 1"); /* Add value into List */
        lv_Rows.setAdapter(listAdapter); /* Put all data in the List into lv_Rows */


        /* "Open" Database */
        btn_openDB.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                /* Get Text from EditText */
                tmp_val_str = et_db_name.getText().toString();
                tmp_val_str_len = tmp_val_str.length(); /* Get the length of EditText String */

                /* Validate: Only run if length is more than 0 */
                if(tmp_val_str_len > 0)
                {
                    db_name = tmp_val_str;
                    tv_db_opened.setText("Database Opened : " + db_name); //Append to [Database Opened: ]
                }
                else
                {
                    util.alert(c,
                            "TextBox Entry [Database Name] has no text",
                            0);
                }
            }
        });

        /* Insert into ListAdapter */
        btn_insertRow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                /* Get Text from EditText */
                tmp_val_str = et_value_input.getText().toString();
                tmp_val_str_len = tmp_val_str.length(); /* Get the length of EditText String */

                /* Validate: Only run if length is more than 0 */
                if(tmp_val_str_len > 0)
                {
                    rowID++;
                    //listAdapter.add(rowID + " " + "|" + " " + tmp_val_str);
                    db_row_ID.add(rowID);
                    db_row_name.add(tmp_val_str);

                    /* Replace rowID with the size of occupied elements */
                    db_row_ID.clear();
                    for(int i=0; i < db_row_name.size(); i++) {
                        db_row_ID.add(i);
                    }

                    total_rows = db_row_ID.size();

                    /* Clear before adding */
                    listAdapter.clear();
                    for(int i=0; i < db_row_ID.size(); i++)
                    {
                        listAdapter.add(db_row_ID.get(i) + " " + "|" + " " + db_row_name.get(i));
                    }
                }
                else
                {
                    util.alert(c,
                            "TextBox Entry [Values] has no text",
                            0);
                }
            }
        });

        /* Edit ArrayLists */
        btn_editValue.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                tmp_val_str = et_value_input.getText().toString();
                tmp_val_str_len = tmp_val_str.length(); /* Get the length of EditText String */

                if(selected_item_row_number < 0 && selected_item_row_value_token.equals(""))
                {
                    util.alert(c, "A row has not yet been selected", 1);
                }
                else {
                    tmp = db_row_name.get(selected_item_row_number);

                    if (tmp_val_str_len > 0) {
                        db_row_name.set(selected_item_row_number, tmp_val_str);

                        total_rows = db_row_ID.size();

                        /* Clear before replacing with updated values */
                        listAdapter.clear();
                        for(int i=0; i < db_row_ID.size(); i++)
                        {
                            listAdapter.add(db_row_ID.get(i) + " " + "|" + " " + db_row_name.get(i));
                        }
                    }
                    else
                    {
                        util.alert(c, "TextBox Entry [Values] has no text - Nothing to edit.",1);
                    }
                }
            }
        });

        /* Clear a value */
        btn_deleteValue.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(selected_item_row_value_token.equals(""))
                {
                    util.alert(c, "A row has not yet been selected", 1);
                }
                else {
                    tmp = db_row_name.get(selected_item_row_number);

                    db_row_name.set(selected_item_row_number, "");

                    total_rows = db_row_ID.size();

                    /* Clear before replacing with updated values */
                    listAdapter.clear();
                    for(int i=0; i < db_row_ID.size(); i++) {
                        if (db_row_name.get(i).length() == 0) {
                            listAdapter.add(db_row_ID.get(i) + " " + "|" + " " + "<EMPTY>");
                        } else {
                            listAdapter.add(db_row_ID.get(i) + " " + "|" + " " + db_row_name.get(i));
                        }
                    }
                }
            }
        });

        /* Delete an entire row - Remove from arraylist */
        btn_deleteRow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(selected_item_row_number < 0 && selected_item_row_value_token.equals(""))
                {
                    util.alert(c, "A row has not yet been selected", 1);
                }
                else {
                    tmp_int = db_row_ID.get(selected_item_row_number);

                    db_row_ID.remove(selected_item_row_number);
                    db_row_name.remove(selected_item_row_number);

                    rowID--; //Remove 1 after deleting

                    total_rows = db_row_ID.size();

                    /* Clear before replacing with updated values */
                    db_row_ID.clear();
                    for(int i=0; i < db_row_name.size(); i++) {
                        /* Replace rowID with the size of occupied elements */
                        db_row_ID.add(i);
                    }

                    listAdapter.clear();
                    for(int i=0; i < db_row_ID.size(); i++)
                    {
                        listAdapter.add(db_row_ID.get(i) + " " + "|" + " " + db_row_name.get(i));
                    }

                    /* Reset the tokens after deletion - Seized to exist */
                    selected_item_row_number = -1;
                    selected_item_row_value_token = "";
                }
            }
        });

        /* Save to text file */
        btn_save_to_text_file.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                util.alert(c, "TODO - Save Text", LENGTH_LONG);
            }
        });

        /* When Listview Item is clicked */
        lv_Rows.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                //alert(listAdapter.getItem(position).toString(), 1);
                selected_item_row_number = position;
                selected_item_row_value_token = db_row_name.get(position);
                util.alert(c,
                        "Selected" + " " + ":" + " " + "\n" +
                                "[" + " " + "\n" +
                                "   Row   ID" + " " + ":" + " " + db_row_ID.get(position).toString() + "\n" +
                                "   Row Name" + " " + ":" + " " + db_row_name.get(position) + "\n" +
                                "]",
                        1);
            }
        });

        /* When Listview is long clicked
        * Open ActionMenu
        *
        */
        lv_Rows.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                util.alert(c,
                        listAdapter.toString(),
                        1);
                return false;
            }
        });

        lv_Rows.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                //alert("Long Click:" + listAdapter.getItem(position).toString(), 1);
                util.alert(c,
                        "Row ID" + " " + ":" + " " + db_row_ID.get(position).toString() + "\n" +
                        "Row Name" + " " + ":" + " " + db_row_name.get(position).toString(),
                        1);
                return true;
                //return false;
            }
        });
    }
}
