package com.example.Database.SQLite3.CountryDBMS;

import android.app.Activity;
import android.app.Application;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.Nullable;

import com.example.Database.SQLite3.CountryDBMS.Helpers.CountryDBManager;
import com.example.extdbms.CountryListActivity;
import com.example.extdbms.R;

public class AddCountryActivity extends Activity implements View.OnClickListener {
    Context c = this;
    Activity a = this;
    Application app = new Application();

    private Button addTodoBtn;
    private EditText subjectEditText;
    private EditText descEditext;

    private CountryDBManager dbManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_country_add_record);
        setTitle("Add Record");

        init_views();

        /* Database crashes on opening */
        dbManager = new CountryDBManager(c);
        dbManager.open();
        addTodoBtn.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch(v.getId())
        {
            case R.id.add_record:
                final String name = subjectEditText.getText().toString();
                final String desc = descEditext.getText().toString();

                Toast.makeText(c, String.format("Name: %1s\nDescription: %2s", name, desc),Toast.LENGTH_LONG).show();
                dbManager.insert(name, desc);

                Intent main = new Intent(AddCountryActivity.this, CountryListActivity.class);
                main.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(main);
                break;
        }
    }

    void init_views()
    {
        subjectEditText = (EditText)findViewById(R.id.subject_edittext);
        descEditext = (EditText)findViewById(R.id.description_edittext);
        addTodoBtn = (Button)findViewById(R.id.add_record);
    }
}
