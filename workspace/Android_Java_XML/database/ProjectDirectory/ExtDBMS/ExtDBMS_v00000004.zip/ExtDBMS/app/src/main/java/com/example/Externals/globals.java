package com.example.Externals;

import android.app.Activity;
import android.content.Context;
import android.os.Environment;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class globals {
    /* Directory Paths */
    public File sdcard = Environment.getExternalStorageDirectory();
    public String cwd = sdcard.getPath();
}
